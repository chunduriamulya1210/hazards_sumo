"""
HAZARD MANAGER - Mumbai Traffic Simulation
Manages all 10 traffic hazards with config compatibility
FIXED VERSION: All identified issues resolved
"""

import random
from typing import Dict, List, Set, Optional, Any
import traci
from dataclasses import dataclass

@dataclass
class HazardEvent:
    """Standardized hazard event structure"""
    hazard_id: int
    hazard_name: str
    start_step: int
    duration_steps: int
    affected_vehicles: Set[str]
    priority: int
    metadata: Dict[str, Any]

# ============================================================================
# 1. ACCIDENT HAZARD
# ============================================================================

class AccidentHazard:
    """ACCIDENT hazard - Priority 1"""
    
    VEHICLE_IMPACT_FACTORS = {
        "truck": 2.5,
        "bus": 2.0,
        "passenger": 1.5,
        "auto_rickshaw": 1.2,
        "motorcycle": 1.0,
        "emergency": 0.3
    }
    
    def __init__(self):
        self.hazard_id = 1
        self.hazard_name = "ACCIDENT"
        self.priority = 1
        self.last_check_step = -float('inf')
        self.affected_vehicles = set()
        self.affected_lanes = set()
        self.original_lane_speeds = {}
        self.active = False

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        if self.active:
            return None
            
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step - self.last_check_step < steps_per_check:
            return None
            
        # Probability check
        accident_prob = config["hazards"]["test_mode_probabilities"]["ACCIDENT"]
        if random.random() > accident_prob:
            self.last_check_step = current_step
            return None
            
        # Minimum vehicle count
        vehicles = traci_conn.vehicle.getIDList()
        if len(vehicles) < config.get("min_vehicles_for_accident", 15):
            self.last_check_step = current_step
            return None
            
        # FIX: Clear previous affected vehicles at start of trigger
        self.affected_vehicles.clear()
        self.affected_lanes.clear()
            
        # Weighted vehicle selection
        weighted_vehicles = []
        for v in vehicles:
            try:
                vtype = traci_conn.vehicle.getTypeID(v)
                vtype_config = config["vehicle_types"].get(vtype, {})
                base_prob = vtype_config.get("probability", 0.1)
                impact = self.VEHICLE_IMPACT_FACTORS.get(vtype, 1.0)
                weight = base_prob * impact
                weighted_vehicles.append((v, weight))
            except:
                continue
                
        if not weighted_vehicles:
            self.last_check_step = current_step
            return None
            
        # Select vehicles
        vehicles_list, weights = zip(*weighted_vehicles)
        max_accidents = min(2, max(1, len(vehicles) // 300))
        chosen = random.choices(vehicles_list, weights=weights, k=max_accidents)
        
        # Apply accident effects
        max_impact = 0
        total_speed_reduction = 0
        vehicle_types_involved = []
        
        for veh in chosen:
            try:
                lane_id = traci_conn.vehicle.getLaneID(veh)
                vtype = traci_conn.vehicle.getTypeID(veh)
                impact = self.VEHICLE_IMPACT_FACTORS.get(vtype, 1.0)
                max_impact = max(max_impact, impact)
                
                if lane_id not in self.original_lane_speeds:
                    self.original_lane_speeds[lane_id] = traci_conn.lane.getMaxSpeed(lane_id)
                
                reduced_speed_kmh = max(5.0, 10.0 / impact)
                reduced_speed_ms = reduced_speed_kmh / 3.6
                total_speed_reduction += reduced_speed_ms
                vehicle_types_involved.append(vtype)
                
                traci_conn.lane.setMaxSpeed(lane_id, reduced_speed_ms)
                traci_conn.vehicle.setSpeed(veh, reduced_speed_ms)
                
                self.affected_vehicles.add(veh)
                self.affected_lanes.add(lane_id)
                
            except:
                continue
                
        if not self.affected_vehicles:
            self.last_check_step = current_step
            return None
            
        # Calculate duration
        base_duration = random.uniform(120, 240)
        duration = base_duration * (1 + (max_impact - 1) * 0.5)
        duration_steps = int(duration / step_length)
        
        self.active = True
        self.last_check_step = current_step
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=duration_steps,
            affected_vehicles=self.affected_vehicles.copy(),
            priority=self.priority,
            metadata={
                "config_compatible": True,
                "probability_used": accident_prob,
                "check_interval": check_interval,
                "max_impact_factor": max_impact,
                "vehicle_types": list(set(vehicle_types_involved)),
                "avg_speed_reduction_ms": total_speed_reduction / len(chosen) if chosen else 0,
                "left_hand_traffic": config["network"]["left_hand_traffic"],
                "duration_seconds": duration,
                "label_source": "simulation_event"
            }
        )

    def clear(self, traci_conn, event):
        if not self.active:
            return
            
        # Restore lane speeds
        for lane_id, original_speed in self.original_lane_speeds.items():
            try:
                traci_conn.lane.setMaxSpeed(lane_id, original_speed)
            except:
                pass
                
        # Restore vehicle speeds
        for veh in self.affected_vehicles:
            if veh in traci_conn.vehicle.getIDList():
                try:
                    traci_conn.vehicle.setSpeed(veh, -1)
                except:
                    pass
        
        # Clear state
        self.original_lane_speeds.clear()
        self.affected_lanes.clear()
        self.affected_vehicles.clear()
        self.active = False

# ============================================================================
# 2. EMERGENCY VEHICLE HAZARD
# ============================================================================

class EmergencyVehicleHazard:
    """EMERGENCY_VEHICLE hazard - Priority 2"""
    
    def __init__(self):
        self.hazard_id = 2
        self.hazard_name = "EMERGENCY_VEHICLE"
        self.priority = 2
        self.active_emergency_vehicles: Dict[str, Dict] = {}
        self.mumbai_factors = {
            "lane_change_aggressiveness": 2.5,
            "speed_multiplier_range": (1.5, 2.0),
            "min_duration": 45,
            "max_duration": 240,
        }

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        interval_s = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(interval_s / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        prob = config["hazards"]["test_mode_probabilities"]["EMERGENCY_VEHICLE"]
        if random.random() > prob:
            return None
            
        # Limit active emergencies
        if len(self.active_emergency_vehicles) >= 3:
            return None
            
        # Find actual emergency vehicles
        emergency_vehicles = []
        for v in traci_conn.vehicle.getIDList():
            try:
                if traci_conn.vehicle.getTypeID(v) == "emergency":
                    # FIX: Prevent stacking on same vehicle
                    if v not in self.active_emergency_vehicles:
                        emergency_vehicles.append(v)
            except:
                continue
        
        if not emergency_vehicles:
            return None
            
        selected = random.sample(emergency_vehicles, min(2, len(emergency_vehicles)))
        affected: Set[str] = set()
        metadata_rows = []
        
        for veh_id in selected:
            try:
                # FIX: Double-check vehicle is not already active
                if veh_id in self.active_emergency_vehicles:
                    continue
                    
                lane_id = traci_conn.vehicle.getLaneID(veh_id)
                lane_speed = traci_conn.lane.getMaxSpeed(lane_id)
                
                # Store original state
                original = {
                    "speed_factor": traci_conn.vehicle.getSpeedFactor(veh_id),
                    "color": traci_conn.vehicle.getColor(veh_id),
                    "min_gap": traci_conn.vehicle.getMinGap(veh_id),
                    "lc_assertive": traci_conn.vehicle.getParameter(
                        veh_id, "laneChangeModel.lcAssertive"
                    ) or "1.0",
                    "lc_pushy": traci_conn.vehicle.getParameter(
                        veh_id, "laneChangeModel.lcPushy"
                    ) or "0.0",
                }
                
                # Calculate emergency parameters
                mult = random.uniform(*self.mumbai_factors["speed_multiplier_range"])
                duration_s = random.uniform(
                    self.mumbai_factors["min_duration"],
                    self.mumbai_factors["max_duration"]
                )
                
                # Respect physical limits
                max_kmh = config["vehicle_types"]["emergency"]["max_speed"]
                max_ms = max_kmh / 3.6
                target_ms = min(max_ms, lane_speed * mult)
                speed_factor = target_ms / lane_speed if lane_speed > 0 else 1.5
                
                # Apply emergency behavior
                traci_conn.vehicle.setSpeedFactor(veh_id, speed_factor)
                traci_conn.vehicle.setMinGap(veh_id, max(0.5, original["min_gap"] * 0.7))
                traci_conn.vehicle.setParameter(
                    veh_id, "laneChangeModel.lcAssertive",
                    str(self.mumbai_factors["lane_change_aggressiveness"])
                )
                traci_conn.vehicle.setParameter(veh_id, "laneChangeModel.lcPushy", "1.5")
                traci_conn.vehicle.setColor(veh_id, (255, 0, 0, 255))
                traci_conn.vehicle.setParameter(veh_id, "hazard.emergency", "true")
                
                self.active_emergency_vehicles[veh_id] = {
                    **original,
                    "start_step": current_step,
                    "duration_steps": int(duration_s / step_length),
                }
                
                affected.add(veh_id)
                metadata_rows.append({
                    "vehicle_id": veh_id,
                    "speed_factor": speed_factor,
                    "duration_seconds": duration_s
                })
                
            except Exception:
                continue
                
        if not affected:
            return None
            
        # Event duration
        max_duration_steps = max(
            v["duration_steps"] for v in self.active_emergency_vehicles.values()
        )
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=max_duration_steps,
            affected_vehicles=affected,
            priority=self.priority,
            metadata={
                "type": "emergency_vehicle",
                "label_source": "simulation_event",
                "vehicle_count": len(affected),
                "check_interval_steps": steps_per_check,
                "emergency_vehicles": metadata_rows,
                "mumbai_adjusted": True,
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def periodic_clear(self, traci_conn, simulation_state):
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        
        to_clear = [
            vid for vid, v in self.active_emergency_vehicles.items()
            if current_step >= v["start_step"] + v["duration_steps"]
        ]
        
        for vid in to_clear:
            try:
                data = self.active_emergency_vehicles[vid]
                traci_conn.vehicle.setSpeedFactor(vid, data["speed_factor"])
                traci_conn.vehicle.setMinGap(vid, data["min_gap"])
                traci_conn.vehicle.setParameter(
                    vid, "laneChangeModel.lcAssertive", data["lc_assertive"]
                )
                traci_conn.vehicle.setParameter(vid, "laneChangeModel.lcPushy", data["lc_pushy"])
                traci_conn.vehicle.setColor(vid, data["color"])
                traci_conn.vehicle.setParameter(vid, "hazard.emergency", "false")
            except Exception:
                pass
                
            del self.active_emergency_vehicles[vid]
            
    def clear(self, traci_conn, event):
        for veh_id, data in list(self.active_emergency_vehicles.items()):
            if veh_id in traci_conn.vehicle.getIDList():
                try:
                    traci_conn.vehicle.setSpeedFactor(veh_id, data["speed_factor"])
                    traci_conn.vehicle.setMinGap(veh_id, data["min_gap"])
                    traci_conn.vehicle.setParameter(
                        veh_id, "laneChangeModel.lcAssertive", data["lc_assertive"]
                    )
                    traci_conn.vehicle.setParameter(
                        veh_id, "laneChangeModel.lcPushy", data["lc_pushy"]
                    )
                    traci_conn.vehicle.setColor(veh_id, data["color"])
                    traci_conn.vehicle.setParameter(veh_id, "hazard.emergency", "false")
                except Exception:
                    pass
                    
            del self.active_emergency_vehicles[veh_id]

# ============================================================================
# 3. CONGESTION HAZARD
# ============================================================================

class CongestionHazard:
    """CONGESTION hazard - Priority 3"""
    
    def __init__(self):
        self.hazard_id = 3
        self.hazard_name = "CONGESTION"
        self.priority = 3
        self.original_lane_speeds: Dict[str, float] = {}
        self.is_active: bool = False

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        if self.is_active:
            return None
            
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        congestion_prob = config["hazards"]["test_mode_probabilities"]["CONGESTION"]
        if random.random() > congestion_prob:
            return None
            
        # Get candidate edges
        candidate_edges = self._get_candidate_edges(traci_conn, simulation_state)
        if not candidate_edges:
            return None
            
        # Choose edges to congest
        max_edges = config["hazards"].get("max_congested_edges", 3)
        num_edges = min(max_edges, max(1, len(candidate_edges) // 10))
        chosen_edges = random.sample(candidate_edges, min(num_edges, len(candidate_edges)))
        
        affected_vehicles: Set[str] = set()
        affected_lanes: List[str] = []
        
        # Apply congestion
        for edge in chosen_edges:
            lanes = self._get_edge_lanes(traci_conn, edge, simulation_state)
            for lane in lanes:
                try:
                    if lane in self.original_lane_speeds:
                        continue
                        
                    original_speed = traci_conn.lane.getMaxSpeed(lane)
                    self.original_lane_speeds[lane] = original_speed
                    
                    reduction = random.uniform(0.4, 0.7)
                    new_speed = original_speed * (1 - reduction)
                    traci_conn.lane.setMaxSpeed(lane, new_speed)
                    
                    vehicles = traci_conn.lane.getLastStepVehicleIDs(lane)
                    affected_vehicles.update(vehicles)
                    affected_lanes.append(lane)
                    
                except Exception:
                    continue
                    
        if not affected_vehicles:
            self.original_lane_speeds.clear()
            return None
            
        # Duration
        min_dur = config["hazards"].get("congestion_min_duration", 120)
        max_dur = config["hazards"].get("congestion_max_duration", 600)
        duration_seconds = random.uniform(min_dur, max_dur)
        duration_steps = int(duration_seconds / step_length)
        
        self.is_active = True
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=duration_steps,
            affected_vehicles=affected_vehicles,
            priority=self.priority,
            metadata={
                "source": "artificial_injection",
                "edges": chosen_edges,
                "lanes_affected": len(affected_lanes),
                "vehicles_affected": len(affected_vehicles),
                "duration_seconds": duration_seconds,
                "label_source": "simulation_event",
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def _get_candidate_edges(self, traci_conn, simulation_state) -> List[str]:
        if simulation_state and "edges_with_traffic" in simulation_state:
            return simulation_state["edges_with_traffic"]
            
        all_edges = list(traci_conn.edge.getIDList())
        if not all_edges:
            return []
            
        sample_size = min(100, len(all_edges))
        return random.sample(all_edges, sample_size)
        
    def _get_edge_lanes(self, traci_conn, edge_id: str, simulation_state) -> List[str]:
        if simulation_state and "edge_to_lanes" in simulation_state:
            return simulation_state["edge_to_lanes"].get(edge_id, [])
            
        lanes = []
        idx = 0
        while True:
            lane_id = f"{edge_id}_{idx}"
            try:
                traci_conn.lane.getMaxSpeed(lane_id)
                lanes.append(lane_id)
                idx += 1
            except Exception:
                break
        return lanes
        
    def clear(self, traci_conn, event):
        if not self.is_active:
            return
            
        for lane, speed in self.original_lane_speeds.items():
            try:
                traci_conn.lane.setMaxSpeed(lane, speed)
            except Exception:
                pass
                
        self.original_lane_speeds.clear()
        self.is_active = False

# ============================================================================
# 4. WRONG_WAY HAZARD
# ============================================================================

class WrongWayHazard:
    """WRONG_WAY hazard - Priority 4"""
    
    def __init__(self):
        self.hazard_id = 4
        self.hazard_name = "WRONG_WAY"
        self.priority = 4
        self.active_wrong_way: Dict[str, Dict] = {}

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        interval_s = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(interval_s / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        prob = config["hazards"]["test_mode_probabilities"]["WRONG_WAY"]
        if random.random() > prob:
            return None
            
        # Candidate selection
        vehicles = [
            v for v in traci_conn.vehicle.getIDList()
            if v not in self.active_wrong_way
        ]
        if not vehicles:
            return None
            
        # Exactly ONE violator
        veh_id = random.choice(vehicles)
        
        try:
            route = traci_conn.vehicle.getRoute(veh_id)
            if not route:
                return None
                
            current_edge = route[0]
            
            # Find opposite edge
            opposite_edge = self._find_opposite_edge(traci_conn, current_edge)
            if not opposite_edge:
                return None
                
            # Force wrong-way routing
            wrong_way_route = [current_edge, opposite_edge]
            traci_conn.vehicle.setRoute(veh_id, wrong_way_route)
            
            duration_s = random.uniform(20, 60)
            duration_steps = int(duration_s / step_length)
            
            # Store original state
            self.active_wrong_way[veh_id] = {
                "original_route": route,
                "start_step": current_step,
                "duration_steps": duration_steps
            }
            
            # Visual marker
            traci_conn.vehicle.setColor(veh_id, (255, 0, 255, 255))
            traci_conn.vehicle.setParameter(veh_id, "hazard.wrong_way", "true")
            
            return HazardEvent(
                hazard_id=self.hazard_id,
                hazard_name=self.hazard_name,
                start_step=current_step,
                duration_steps=duration_steps,
                affected_vehicles={veh_id},
                priority=self.priority,
                metadata={
                    "type": "wrong_way_driving",
                    "vehicle_id": veh_id,
                    "label_source": "simulation_event",
                    "left_hand_traffic": config["network"]["left_hand_traffic"]
                }
            )
            
        except Exception:
            return None
            
    def _find_opposite_edge(self, traci_conn, edge_id) -> Optional[str]:
        try:
            from_node = traci_conn.edge.getFromNode(edge_id)
            to_node = traci_conn.edge.getToNode(edge_id)
            
            for e in traci_conn.edge.getIDList():
                if (
                    traci_conn.edge.getFromNode(e) == to_node and
                    traci_conn.edge.getToNode(e) == from_node
                ):
                    return e
        except Exception:
            pass
        return None
        
    def periodic_clear(self, traci_conn, simulation_state):
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        
        to_clear = [
            v for v, d in self.active_wrong_way.items()
            if current_step >= d["start_step"] + d["duration_steps"]
        ]
        
        for veh_id in to_clear:
            self._restore_vehicle(traci_conn, veh_id)
            
    def clear(self, traci_conn, event):
        for veh_id in list(self.active_wrong_way.keys()):
            self._restore_vehicle(traci_conn, veh_id)
            
    def _restore_vehicle(self, traci_conn, veh_id):
        data = self.active_wrong_way.get(veh_id)
        if not data:
            return
            
        if veh_id in traci_conn.vehicle.getIDList():
            try:
                traci_conn.vehicle.setRoute(veh_id, data["original_route"])
                traci_conn.vehicle.setColor(veh_id, (255, 255, 255, 255))
                traci_conn.vehicle.setParameter(veh_id, "hazard.wrong_way", "false")
            except Exception:
                pass
                
        del self.active_wrong_way[veh_id]

# ============================================================================
# 5. IGNORE_RED_LIGHT HAZARD
# ============================================================================

class IgnoreRedLightHazard:
    """IGNORE_RED_LIGHT hazard - Priority 5"""
    
    def __init__(self):
        self.hazard_id = 5
        self.hazard_name = "IGNORE_RED_LIGHT"
        self.priority = 5
        self.active_violators: Dict[str, Dict] = {}

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        interval_s = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(interval_s / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        prob = config["hazards"]["test_mode_probabilities"]["IGNORE_RED_LIGHT"]
        if random.random() > prob:
            return None
            
        # Find vehicles approaching RED lights
        candidates = []
        for veh_id in traci_conn.vehicle.getIDList():
            if veh_id in self.active_violators:
                continue
                
            tls_info = traci_conn.vehicle.getNextTLS(veh_id)
            if not tls_info:
                continue
                
            tls_id, link_index, dist = tls_info[0]
            
            # Only vehicles close to junction
            if dist > 25:
                continue
                
            state = traci_conn.trafficlight.getRedYellowGreenState(tls_id)
            if state[link_index].lower() != "r":
                continue
                
            candidates.append((veh_id, tls_id))
            
        if not candidates:
            return None
            
        # Exactly ONE violator
        veh_id, tls_id = random.choice(candidates)
        
        try:
            # Store original state
            original_state = {
                "speed_factor": traci_conn.vehicle.getSpeedFactor(veh_id),
                "decel": traci_conn.vehicle.getDecel(veh_id),
                "color": traci_conn.vehicle.getColor(veh_id)
            }
            
            # Force red light violation
            traci_conn.vehicle.setSpeedFactor(veh_id, max(1.1, original_state["speed_factor"]))
            traci_conn.vehicle.setDecel(veh_id, 1.0)
            traci_conn.vehicle.setColor(veh_id, (255, 255, 0, 255))
            traci_conn.vehicle.setParameter(veh_id, "hazard.ignore_red_light", "true")
            
            duration_s = random.uniform(6, 12)
            duration_steps = int(duration_s / step_length)
            
            self.active_violators[veh_id] = {
                "original_state": original_state,
                "start_step": current_step,
                "duration_steps": duration_steps
            }
            
            return HazardEvent(
                hazard_id=self.hazard_id,
                hazard_name=self.hazard_name,
                start_step=current_step,
                duration_steps=duration_steps,
                affected_vehicles={veh_id},
                priority=self.priority,
                metadata={
                    "type": "ignore_red_light",
                    "vehicle_id": veh_id,
                    "tls_id": tls_id,
                    "label_source": "simulation_event",
                    "left_hand_traffic": config["network"]["left_hand_traffic"]
                }
            )
            
        except Exception:
            return None
            
    def periodic_clear(self, traci_conn, simulation_state):
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        
        to_clear = [
            v for v, d in self.active_violators.items()
            if current_step >= d["start_step"] + d["duration_steps"]
        ]
        
        for veh_id in to_clear:
            self._restore_vehicle(traci_conn, veh_id)
            
    def clear(self, traci_conn, event):
        for veh_id in list(self.active_violators.keys()):
            self._restore_vehicle(traci_conn, veh_id)
            
    def _restore_vehicle(self, traci_conn, veh_id):
        data = self.active_violators.get(veh_id)
        if not data:
            return
            
        if veh_id in traci_conn.vehicle.getIDList():
            try:
                orig = data["original_state"]
                traci_conn.vehicle.setSpeedFactor(veh_id, orig["speed_factor"])
                traci_conn.vehicle.setDecel(veh_id, orig["decel"])
                traci_conn.vehicle.setColor(veh_id, orig["color"])
                traci_conn.vehicle.setParameter(veh_id, "hazard.ignore_red_light", "false")
            except Exception:
                pass
                
        del self.active_violators[veh_id]

# ============================================================================
# 6. SUDDEN_BRAKING HAZARD
# ============================================================================

class SuddenBrakingHazard:
    """SUDDEN_BRAKING hazard - Priority 6"""
    
    def __init__(self):
        self.hazard_id = 6
        self.hazard_name = "SUDDEN_BRAKING"
        self.priority = 6
        self.active_brakers: Set[str] = set()

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        prob = config["hazards"]["test_mode_probabilities"]["SUDDEN_BRAKING"]
        if random.random() > prob:
            return None
            
        vehicles = traci_conn.vehicle.getIDList()
        if not vehicles:
            return None
            
        # Scalable selection
        num_brakers = min(3, max(1, len(vehicles) // 600))
        chosen = random.sample(vehicles, min(num_brakers, len(vehicles)))
        
        affected: Set[str] = set()
        
        for veh_id in chosen:
            try:
                traci_conn.vehicle.setSpeed(veh_id, 0)
                traci_conn.vehicle.setColor(veh_id, (80, 80, 255, 255))
                self.active_brakers.add(veh_id)
                affected.add(veh_id)
            except traci.TraCIException:
                continue
                
        if not affected:
            return None
            
        # Very short impulse
        duration_seconds = random.uniform(1.5, 3.5)
        duration_steps = max(1, int(duration_seconds / step_length))
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=duration_steps,
            affected_vehicles=affected,
            priority=self.priority,
            metadata={
                "type": "sudden_braking",
                "vehicle_count": len(affected),
                "duration_seconds": duration_seconds,
                "label_source": "simulation_event",
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def clear(self, traci_conn, event):
        for veh_id in self.active_brakers:
            if veh_id in traci_conn.vehicle.getIDList():
                try:
                    traci_conn.vehicle.setSpeed(veh_id, -1)
                    traci_conn.vehicle.setColor(veh_id, (255, 255, 255, 255))
                except traci.TraCIException:
                    pass
                    
        self.active_brakers.clear()

# ============================================================================
# 7. AGGRESSIVE_LANE_CHANGE HAZARD
# ============================================================================

class AggressiveLaneChangeHazard:
    """AGGRESSIVE_LANE_CHANGE hazard - Priority 7"""
    
    def __init__(self):
        self.hazard_id = 7
        self.hazard_name = "AGGRESSIVE_LANE_CHANGE"
        self.priority = 7
        self.active_lane_changers: Dict[str, int] = {}
        self.original_lc_params: Dict[str, Dict[str, str]] = {}
        self.original_color: Dict[str, tuple] = {}
        self.vehicle_aggressiveness = {
            "motorcycle": 1.5,
            "auto_rickshaw": 1.3,
            "passenger": 1.0,
            "truck": 0.8,
            "bus": 0.7,
            "emergency": 0.1
        }

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        base_prob = config["hazards"]["test_mode_probabilities"]["AGGRESSIVE_LANE_CHANGE"]
        total_vehicles = len(traci_conn.vehicle.getIDList())
        adjusted_prob = base_prob * min(2.0, total_vehicles / 400.0)
        
        if random.random() > adjusted_prob:
            return None
            
        # Select candidate vehicles
        candidates = []
        for veh in traci_conn.vehicle.getIDList():
            if veh in self.active_lane_changers:
                continue
            try:
                if abs(traci_conn.vehicle.getLateralSpeed(veh)) > 0.1:
                    continue
                candidates.append(veh)
            except:
                continue
                
        if not candidates:
            return None
            
        weighted = []
        for veh in candidates[:200]:
            try:
                vtype = traci_conn.vehicle.getTypeID(veh)
                base = self.vehicle_aggressiveness.get(vtype, 1.0)
                speed = traci_conn.vehicle.getSpeed(veh)
                weight = base * min(2.0, speed / 13.89)
                weighted.append((veh, weight))
            except:
                continue
                
        if not weighted:
            return None
            
        vehicles, weights = zip(*weighted)
        k = min(len(vehicles), max(1, total_vehicles // 300))
        chosen = random.choices(vehicles, weights=weights, k=k)
        
        affected: Set[str] = set()
        max_end_step = current_step
        
        for veh in chosen:
            try:
                lane_id = traci_conn.vehicle.getLaneID(veh)
                lane_idx = traci_conn.vehicle.getLaneIndex(veh)
                edge_id = traci_conn.lane.getEdgeID(lane_id)
                total_lanes = traci_conn.edge.getLaneNumber(edge_id)
                
                direction = self._choose_direction(
                    lane_idx, total_lanes, config["network"]["left_hand_traffic"]
                )
                if direction is None:
                    continue
                    
                target_lane = lane_idx + direction
                
                # Store original params
                self.original_lc_params[veh] = {
                    "lcAssertive": traci_conn.vehicle.getParameter(veh, "laneChangeModel.lcAssertive"),
                    "lcPushy": traci_conn.vehicle.getParameter(veh, "laneChangeModel.lcPushy")
                }
                self.original_color[veh] = traci_conn.vehicle.getColor(veh)
                
                duration_sec = random.uniform(3.0, 8.0)
                duration_steps = int(duration_sec / step_length)
                
                traci_conn.vehicle.changeLane(veh, target_lane, duration_steps)
                traci_conn.vehicle.setParameter(veh, "laneChangeModel.lcAssertive", "2.0")
                traci_conn.vehicle.setParameter(veh, "laneChangeModel.lcPushy", "1.0")
                traci_conn.vehicle.setColor(veh, (255, 120, 120, 255))
                
                end_step = current_step + duration_steps
                self.active_lane_changers[veh] = end_step
                affected.add(veh)
                max_end_step = max(max_end_step, end_step)
                
            except:
                continue
                
        if not affected:
            return None
            
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=max_end_step - current_step,
            affected_vehicles=affected,
            priority=self.priority,
            metadata={
                "source": "aggressive_lane_change",
                "vehicles": list(affected),
                "probability_used": base_prob,
                "density_adjusted_prob": adjusted_prob,
                "label_source": "simulation_event",
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def _choose_direction(self, lane, total, left_hand):
        if total <= 1:
            return None
        options = []
        if lane > 0:
            options.append(-1)
        if lane < total - 1:
            options.append(1)
        if not options:
            return None
        weights = [0.7 if d == -1 else 0.3 for d in options] if left_hand else None
        return random.choices(options, weights=weights, k=1)[0]
        
    # FIX: Clear method that accepts both event and simulation_state
    def clear(self, traci_conn, event_or_state=None):
        # Determine current step
        if isinstance(event_or_state, dict) and "step" in event_or_state:
            current_step = event_or_state["step"]
        elif isinstance(event_or_state, HazardEvent):
            current_step = event_or_state.start_step
        else:
            # Default to clearing all
            current_step = float('inf')
            
        to_clear = [
            v for v, end in self.active_lane_changers.items() 
            if current_step >= end
        ]
        
        for veh in to_clear:
            if veh in traci_conn.vehicle.getIDList():
                try:
                    params = self.original_lc_params.get(veh, {})
                    traci_conn.vehicle.setParameter(
                        veh, "laneChangeModel.lcAssertive", 
                        params.get("lcAssertive", "1.0")
                    )
                    traci_conn.vehicle.setParameter(
                        veh, "laneChangeModel.lcPushy", 
                        params.get("lcPushy", "0.0")
                    )
                    traci_conn.vehicle.setColor(
                        veh, self.original_color.get(veh, (255,255,255,255))
                    )
                except:
                    pass
                    
            self.active_lane_changers.pop(veh, None)
            self.original_lc_params.pop(veh, None)
            self.original_color.pop(veh, None)

# ============================================================================
# 8. TAILGATING HAZARD
# ============================================================================

class TailgatingHazard:
    """TAILGATING hazard - Priority 8"""
    
    def __init__(self):
        self.hazard_id = 8
        self.hazard_name = "TAILGATING"
        self.priority = 8
        self.active_tailgaters: Dict[str, Dict] = {}
        self.vehicle_tailgating_tendency = {
            "motorcycle": 1.6,
            "auto_rickshaw": 1.3,
            "passenger": 1.0,
            "truck": 0.8,
            "bus": 0.7,
            "emergency": 0.3
        }

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        base_prob = config["hazards"]["test_mode_probabilities"]["TAILGATING"]
        total_vehicles = len(traci_conn.vehicle.getIDList())
        density_factor = min(2.0, total_vehicles / 300.0)
        
        if random.random() > base_prob * density_factor:
            return None
            
        # Get candidate vehicles
        candidates = self._get_candidate_vehicles(traci_conn)
        if not candidates:
            return None
            
        weighted = []
        for veh_id in candidates[:150]:
            weight = self._calculate_tailgating_weight(traci_conn, veh_id, config)
            weighted.append((veh_id, weight))
            
        if not weighted:
            return None
            
        vehicles, weights = zip(*weighted)
        num_tailgaters = self._calculate_tailgater_count(total_vehicles, config)
        chosen = random.choices(vehicles, weights=weights, k=min(num_tailgaters, len(vehicles)))
        
        affected: Set[str] = set()
        metadata_rows = []
        
        for veh_id in chosen:
            try:
                vtype = traci_conn.vehicle.getTypeID(veh_id)
                original_gap = traci_conn.vehicle.getMinGap(veh_id)
                leader = traci_conn.vehicle.getLeader(veh_id, 50.0)
                
                if original_gap < 1.0 or not leader:
                    continue
                    
                original_speed_factor = traci_conn.vehicle.getSpeedFactor(veh_id)
                original_color = traci_conn.vehicle.getColor(veh_id)
                
                # Vehicle-type-aware reduction
                reduction = {
                    "motorcycle": 0.20,
                    "auto_rickshaw": 0.25,
                    "truck": 0.40,
                    "bus": 0.40
                }.get(vtype, 0.30)
                
                new_gap = max(0.3, original_gap * reduction)
                new_speed_factor = min(1.2, original_speed_factor * 1.05)
                
                traci_conn.vehicle.setMinGap(veh_id, new_gap)
                traci_conn.vehicle.setSpeedFactor(veh_id, new_speed_factor)
                traci_conn.vehicle.setColor(veh_id, (255, 140, 0, 255))
                
                duration_s = random.uniform(
                    config.get("tailgating_min_duration", 30),
                    config.get("tailgating_max_duration", 90)
                )
                
                self.active_tailgaters[veh_id] = {
                    "original_gap": original_gap,
                    "original_speed_factor": original_speed_factor,
                    "original_color": original_color,
                    "end_step": current_step + int(duration_s / step_length)
                }
                
                affected.add(veh_id)
                metadata_rows.append({
                    "vehicle_id": veh_id,
                    "vehicle_type": vtype,
                    "gap_reduction_pct": (1 - reduction) * 100,
                    "leader_distance_m": leader[1]
                })
                
            except Exception:
                continue
                
        if not affected:
            return None
            
        max_end_step = max(d["end_step"] for d in self.active_tailgaters.values())
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=max_end_step - current_step,
            affected_vehicles=affected,
            priority=self.priority,
            metadata={
                "type": "tailgating",
                "vehicle_count": len(affected),
                "density_adjusted": True,
                "label_source": "simulation_event",
                "tailgating_data": metadata_rows,
                "hazard_severity": self._calculate_tailgating_severity(metadata_rows),
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def _get_candidate_vehicles(self, traci_conn) -> list:
        vehicles = traci_conn.vehicle.getIDList()
        candidates = []
        
        for veh_id in vehicles[:200]:
            try:
                if veh_id in self.active_tailgaters:
                    continue
                if traci_conn.vehicle.getSpeed(veh_id) < 5.0:
                    continue
                leader = traci_conn.vehicle.getLeader(veh_id, 50.0)
                if not leader or leader[1] > 30.0:
                    continue
                candidates.append(veh_id)
            except Exception:
                continue
                
        return candidates
        
    def _calculate_tailgating_weight(self, traci_conn, veh_id, config) -> float:
        try:
            vtype = traci_conn.vehicle.getTypeID(veh_id)
            base = self.vehicle_tailgating_tendency.get(vtype, 1.0)
            
            speed = traci_conn.vehicle.getSpeed(veh_id)
            speed_weight = min(2.0, speed / 20.0)
            
            leader = traci_conn.vehicle.getLeader(veh_id, 50.0)
            gap_weight = 2.0 - min(2.0, leader[1] / 15.0) if leader else 1.0
            
            return min(3.0, max(0.1, base * speed_weight * gap_weight))
        except Exception:
            return 0.5
            
    def _calculate_tailgater_count(self, total, config) -> int:
        if total < 100:
            return 1
        if total < 300:
            return 2
        return min(config.get("max_tailgaters", 3), max(1, total // 150))
        
    def _calculate_tailgating_severity(self, rows) -> str:
        if not rows:
            return "low"
        avg = sum(r["gap_reduction_pct"] for r in rows) / len(rows)
        if avg > 60:
            return "high"
        if avg > 40:
            return "medium"
        return "low"
        
    def periodic_clear(self, traci_conn, simulation_state):
        current_step = simulation_state.get("step", 0)
        
        to_clear = [
            v for v, d in self.active_tailgaters.items()
            if current_step >= d["end_step"]
        ]
        
        for veh_id in to_clear:
            if veh_id in traci_conn.vehicle.getIDList():
                try:
                    d = self.active_tailgaters[veh_id]
                    traci_conn.vehicle.setMinGap(veh_id, d["original_gap"])
                    traci_conn.vehicle.setSpeedFactor(veh_id, d["original_speed_factor"])
                    traci_conn.vehicle.setColor(veh_id, d["original_color"])
                except Exception:
                    pass
            del self.active_tailgaters[veh_id]

# ============================================================================
# 9. OVERSPEEDING HAZARD
# ============================================================================

class OverspeedingHazard:
    """OVERSPEEDING hazard - Priority 9"""
    
    def __init__(self):
        self.hazard_id = 9
        self.hazard_name = "OVERSPEEDING"
        self.priority = 9
        self.active_overspeeders: Dict[str, float] = {}

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        prob = config["hazards"]["test_mode_probabilities"]["SPEEDING"]  # Note: "SPEEDING" not "OVERSPEEDING"
        if random.random() > prob:
            return None
            
        vehicles = traci_conn.vehicle.getIDList()
        if not vehicles:
            return None
            
        # Scalable violator count
        num_violators = min(4, max(1, len(vehicles) // 500))
        candidates = [v for v in vehicles if v not in self.active_overspeeders]
        
        if not candidates:
            return None
            
        chosen = random.sample(candidates, min(num_violators, len(candidates)))
        affected_vehicles: Set[str] = set()
        
        for veh_id in chosen:
            try:
                original_factor = traci_conn.vehicle.getSpeedFactor(veh_id)
                overspeed_factor = random.uniform(1.3, 1.6)
                
                traci_conn.vehicle.setSpeedFactor(veh_id, overspeed_factor)
                traci_conn.vehicle.setColor(veh_id, (255, 80, 80, 255))
                
                self.active_overspeeders[veh_id] = original_factor
                affected_vehicles.add(veh_id)
                
            except traci.TraCIException:
                continue
                
        if not affected_vehicles:
            return None
            
        # Event duration
        duration_seconds = random.uniform(30, 120)
        duration_steps = int(duration_seconds / step_length)
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=duration_steps,
            affected_vehicles=affected_vehicles,
            priority=self.priority,
            metadata={
                "type": "overspeeding",
                "vehicle_count": len(affected_vehicles),
                "duration_seconds": duration_seconds,
                "label_source": "simulation_event",
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def clear(self, traci_conn, event):
        for veh_id, original_factor in self.active_overspeeders.items():
            if veh_id in traci_conn.vehicle.getIDList():
                try:
                    traci_conn.vehicle.setSpeedFactor(veh_id, original_factor)
                    traci_conn.vehicle.setColor(veh_id, (255, 255, 255, 255))
                except traci.TraCIException:
                    pass
                    
        self.active_overspeeders.clear()

# ============================================================================
# 10. SLIPPERY_ROAD HAZARD
# ============================================================================

class SlipperyRoadHazard:
    """SLIPPERY_ROAD hazard - Priority 10"""
    
    def __init__(self):
        self.hazard_id = 10  # Fixed: was 11, should be 10 to match config
        self.hazard_name = "SLIPPERY_ROAD"
        self.priority = 10
        self.is_active: bool = False
        self.affected_lanes: Set[str] = set()
        self.original_friction: Dict[str, float] = {}

    def trigger(self, traci_conn, config, simulation_state=None) -> Optional[HazardEvent]:
        if self.is_active:
            return None
            
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        step_length = config["simulation"]["step_length"]
        
        # Interval check
        check_interval = config["hazards"]["hazard_check_interval_seconds"]
        steps_per_check = max(1, int(check_interval / step_length))
        if current_step % steps_per_check != 0:
            return None
            
        # Probability check
        prob = config["hazards"]["test_mode_probabilities"]["SLIPPERY_ROAD"]
        if random.random() > prob:
            return None
            
        # Candidate edges (non-internal)
        edges = [e for e in traci_conn.edge.getIDList() if ":" not in e]
        if not edges:
            return None
            
        edge = random.choice(edges)
        affected_vehicles: Set[str] = set()
        
        lane_count = traci_conn.edge.getLaneNumber(edge)
        for i in range(lane_count):
            lane_id = f"{edge}_{i}"
            try:
                original = traci_conn.lane.getFriction(lane_id)
                self.original_friction[lane_id] = original
                
                # Realistic wet-road friction
                slippery = random.uniform(0.6, 0.8)
                traci_conn.lane.setFriction(lane_id, slippery)
                
                vehicles = traci_conn.lane.getLastStepVehicleIDs(lane_id)
                affected_vehicles.update(vehicles)
                self.affected_lanes.add(lane_id)
                
            except:
                continue
                
        if not self.affected_lanes:
            self.original_friction.clear()
            return None
            
        # Duration: 1–4 minutes
        duration_seconds = random.uniform(60, 240)
        duration_steps = int(duration_seconds / step_length)
        
        self.is_active = True
        
        return HazardEvent(
            hazard_id=self.hazard_id,
            hazard_name=self.hazard_name,
            start_step=current_step,
            duration_steps=duration_steps,
            affected_vehicles=affected_vehicles,
            priority=self.priority,
            metadata={
                "type": "slippery_road",
                "edge": edge,
                "lanes_affected": len(self.affected_lanes),
                "duration_seconds": duration_seconds,
                "label_source": "simulation_event",
                "left_hand_traffic": config["network"]["left_hand_traffic"]
            }
        )
        
    def clear(self, traci_conn, event):
        if not self.is_active:
            return
            
        for lane, friction in self.original_friction.items():
            try:
                traci_conn.lane.setFriction(lane, friction)
            except:
                pass
                
        self.original_friction.clear()
        self.affected_lanes.clear()
        self.is_active = False

# ============================================================================
# MASTER HAZARD MANAGER
# ============================================================================

class HazardManager:
    """
    Master manager for all traffic hazards in Mumbai simulation
    
    Features:
    - Manages all 10 hazard types
    - Event-driven triggering based on config
    - Scalable for 100-1000+ vehicles
    - Mumbai-specific adjustments
    - ML-safe ground truth labeling
    - Compatible with sliding window analysis
    """
    
    def __init__(self, config: Dict):
        self.config = config
        
        # Initialize all hazard handlers
        self.hazards = {
            1: AccidentHazard(),
            2: EmergencyVehicleHazard(),
            3: CongestionHazard(),
            4: WrongWayHazard(),
            5: IgnoreRedLightHazard(),
            6: SuddenBrakingHazard(),
            7: AggressiveLaneChangeHazard(),
            8: TailgatingHazard(),
            9: OverspeedingHazard(),
            10: SlipperyRoadHazard()  # Fixed: key 10 not 11
        }
        
        # Active events tracking
        self.active_events: List[HazardEvent] = []
        
    def trigger_hazards(self, traci_conn, simulation_state=None) -> List[HazardEvent]:
        """
        Trigger all hazards based on their probabilities and intervals
        Returns list of triggered hazard events
        """
        triggered_events = []
        
        for hazard_id, hazard in self.hazards.items():
            try:
                event = hazard.trigger(traci_conn, self.config, simulation_state)
                if event:
                    self.active_events.append(event)
                    triggered_events.append(event)
                    
                    # Log triggering for debugging
                    print(f"[Hazard] {hazard.hazard_name} triggered at step {event.start_step}")
                    
            except Exception as e:
                print(f"[Error] Hazard {hazard_id} failed: {e}")
                continue
                
        return triggered_events
        
    def clear_expired_events(self, traci_conn, simulation_state):
        """
        Clear events that have expired based on their duration
        """
        current_step = simulation_state.get("step", 0) if simulation_state else 0
        
        # Clear events that have expired
        events_to_keep = []
        for event in self.active_events:
            if current_step < event.start_step + event.duration_steps:
                events_to_keep.append(event)
            else:
                # Event has expired, clear it
                hazard = self.hazards.get(event.hazard_id)
                if hazard:
                    hazard.clear(traci_conn, event)
                    
        self.active_events = events_to_keep
        
    def periodic_clear_hazards(self, traci_conn, simulation_state):
        """
        Call periodic clear methods for all hazards
        """
        for hazard in self.hazards.values():
            if hasattr(hazard, 'periodic_clear'):
                try:
                    hazard.periodic_clear(traci_conn, simulation_state)
                except Exception as e:
                    print(f"[Warning] Periodic clear failed: {e}")
                    
    def get_active_hazards(self) -> List[Dict]:
        """
        Get information about currently active hazards
        """
        active_info = []
        for event in self.active_events:
            active_info.append({
                "hazard_id": event.hazard_id,
                "hazard_name": event.hazard_name,
                "start_step": event.start_step,
                "duration_steps": event.duration_steps,
                "affected_vehicles": len(event.affected_vehicles),
                "priority": event.priority,
                **event.metadata
            })
        return active_info
        
    def clear_all_hazards(self, traci_conn):
        """
        Force clear all active hazards (e.g., on simulation reset)
        """
        for hazard in self.hazards.values():
            # Create a dummy event for clearing
            dummy_event = HazardEvent(
                hazard_id=hazard.hazard_id,
                hazard_name=hazard.hazard_name,
                start_step=0,
                duration_steps=0,
                affected_vehicles=set(),
                priority=hazard.priority,
                metadata={}
            )
            hazard.clear(traci_conn, dummy_event)
            
        self.active_events.clear()

# ============================================================================
# SIMULATION INTEGRATION EXAMPLE
# ============================================================================

"""
Example usage in main simulation loop:

# Initialize
hazard_manager = HazardManager(config)

# In simulation loop:
simulation_state = {
    "step": int(traci.simulation.getTime() / config["simulation"]["step_length"]),
    "total_vehicles": len(traci.vehicle.getIDList()),
    "edges_with_traffic": [...],  # Optional pre-computed
    "edge_to_lanes": {...}       # Optional pre-computed
}

# Trigger hazards
triggered_events = hazard_manager.trigger_hazards(traci, simulation_state)

# Process triggered events (e.g., for ML logging)
for event in triggered_events:
    log_hazard_event(event)  # Your logging function
    
# Clear expired events
hazard_manager.clear_expired_events(traci, simulation_state)

# Periodic clearing
hazard_manager.periodic_clear_hazards(traci, simulation_state)

# Get active hazards info
active_hazards = hazard_manager.get_active_hazards()
"""

print("Hazard Manager initialized with 10 hazard types for Mumbai traffic simulation")