"""
TRAFFIC ANALYTICS - Mumbai Traffic Simulation
Collects and analyzes traffic data, calculates metrics, and generates insights
"""

import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict, deque
import statistics
import json
from datetime import datetime


class TrafficAnalytics:
    """
    Collects and analyzes traffic data for insights and ML features
    """
    
    def __init__(self, config: Dict):
        """
        Initialize traffic analytics
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.analytics_config = config.get("traffic_analytics", {})
        
        # Data buffers
        self.speed_history = defaultdict(lambda: deque(maxlen=100))
        self.acceleration_history = defaultdict(lambda: deque(maxlen=100))
        self.density_history = deque(maxlen=100)
        self.flow_history = deque(maxlen=100)
        self.hazard_history = deque(maxlen=1000)
        
        # Real-time metrics
        self.current_metrics = {
            "avg_speed": 0.0,
            "avg_acceleration": 0.0,
            "congestion_level": "low",
            "hazard_count": 0,
            "vehicle_count": 0,
            "emergency_vehicles": 0,
            "throughput": 0.0,
            "avg_travel_time": 0.0
        }
        
        # Hazard analytics
        self.hazard_stats = {
            "total_hazards": 0,
            "hazards_by_type": defaultdict(int),
            "hazard_durations": defaultdict(list),
            "affected_vehicles": 0,
            "hazard_severity": defaultdict(int)
        }
        
        # Window-based analytics
        self.window_size = self.analytics_config.get("window_size_seconds", 60)
        self.window_step = self.analytics_config.get("window_step_seconds", 10)
        
        # Historical data
        self.historical_data = []
        
        # Statistics
        self.stats = {
            "updates": 0,
            "data_points": 0,
            "hazards_analyzed": 0,
            "last_update": None
        }
        
        print(f"Traffic Analytics initialized:")
        print(f"  Window size: {self.window_size}s")
        print(f"  Window step: {self.window_step}s")
    
    def update(self, traci_conn, simulation_state: Dict):
        """
        Update analytics with current simulation state
        
        Args:
            traci_conn: TraCI connection
            simulation_state: Current simulation state
        """
        try:
            # Get current time
            current_time = simulation_state.get("simulation_time", 0)
            
            # Collect basic metrics
            self._collect_basic_metrics(traci_conn, simulation_state)
            
            # Calculate derived metrics
            self._calculate_derived_metrics(traci_conn)
            
            # Update congestion analysis
            self._update_congestion_analysis(traci_conn)
            
            # Update hazard statistics
            self._update_hazard_statistics()
            
            # Store historical data periodically
            if simulation_state.get("step", 0) % 100 == 0:  # Every 100 steps
                self._store_historical_snapshot(current_time)
            
            # Update statistics
            self.stats["updates"] += 1
            self.stats["last_update"] = current_time
            
        except Exception as e:
            print(f"⚠ Analytics update error: {e}")
    
    def _collect_basic_metrics(self, traci_conn, simulation_state: Dict):
        """
        Collect basic traffic metrics
        
        Args:
            traci_conn: TraCI connection
            simulation_state: Simulation state
        """
        vehicles = traci_conn.vehicle.getIDList()
        vehicle_count = len(vehicles)
        self.current_metrics["vehicle_count"] = vehicle_count
        
        if vehicle_count == 0:
            return
        
        # Collect speeds and accelerations
        speeds = []
        accelerations = []
        emergency_count = 0
        
        for veh_id in vehicles[:200]:  # Sample up to 200 vehicles
            try:
                speed = traci_conn.vehicle.getSpeed(veh_id)
                speeds.append(speed)
                
                # Try to get acceleration
                try:
                    accel = traci_conn.vehicle.getAcceleration(veh_id)
                    accelerations.append(accel)
                except:
                    pass
                
                # Count emergency vehicles
                vtype = traci_conn.vehicle.getTypeID(veh_id)
                if vtype == "emergency":
                    emergency_count += 1
                    
            except:
                continue
        
        # Update metrics
        if speeds:
            avg_speed = sum(speeds) / len(speeds)
            self.current_metrics["avg_speed"] = avg_speed
            self.current_metrics["emergency_vehicles"] = emergency_count
            
            # Store in history
            self.speed_history["global"].append(avg_speed)
            
            # Store per-vehicle type speeds
            self._store_vehicle_type_speeds(traci_conn, vehicles)
        
        if accelerations:
            avg_accel = sum(accelerations) / len(accelerations)
            self.current_metrics["avg_acceleration"] = avg_accel
            self.acceleration_history["global"].append(avg_accel)
        
        # Calculate flow (vehicles per hour)
        edges = traci_conn.edge.getIDList()
        total_flow = 0
        
        for edge_id in edges[:50]:  # Sample edges
            try:
                flow = traci_conn.edge.getLastStepVehicleNumber(edge_id)
                total_flow += flow
            except:
                continue
        
        flow_per_hour = (total_flow / len(edges[:50])) * 3600 if edges else 0
        self.current_metrics["throughput"] = flow_per_hour
        self.flow_history.append(flow_per_hour)
    
    def _store_vehicle_type_speeds(self, traci_conn, vehicles: List[str]):
        """
        Store average speeds by vehicle type
        
        Args:
            traci_conn: TraCI connection
            vehicles: List of vehicle IDs
        """
        type_speeds = defaultdict(list)
        
        for veh_id in vehicles[:100]:  # Sample
            try:
                vtype = traci_conn.vehicle.getTypeID(veh_id)
                speed = traci_conn.vehicle.getSpeed(veh_id)
                type_speeds[vtype].append(speed)
            except:
                continue
        
        for vtype, speeds in type_speeds.items():
            if speeds:
                avg_speed = sum(speeds) / len(speeds)
                self.speed_history[vtype].append(avg_speed)
    
    def _calculate_derived_metrics(self, traci_conn):
        """
        Calculate derived metrics from basic data
        """
        # Calculate density (vehicles per km)
        edges = traci_conn.edge.getIDList()
        if not edges:
            return
        
        total_length = 0
        total_vehicles = 0
        
        for edge_id in edges[:100]:  # Sample edges
            try:
                length = traci_conn.edge.getLength(edge_id)
                vehicles = traci_conn.edge.getLastStepVehicleNumber(edge_id)
                total_length += length
                total_vehicles += vehicles
            except:
                continue
        
        if total_length > 0:
            density = (total_vehicles / total_length) * 1000  # vehicles per km
            self.density_history.append(density)
            
            # Calculate travel time index (simplified)
            avg_speed = self.current_metrics["avg_speed"]
            free_flow_speed = self.config["network"].get("default_speed", 50.0) / 3.6
            
            if free_flow_speed > 0 and avg_speed > 0:
                travel_time_index = free_flow_speed / avg_speed
                self.current_metrics["avg_travel_time"] = travel_time_index
    
    def _update_congestion_analysis(self, traci_conn):
        """
        Update congestion level analysis
        """
        avg_speed = self.current_metrics["avg_speed"]
        density = self.density_history[-1] if self.density_history else 0
        
        # Determine congestion level
        congestion_level = "low"
        
        if avg_speed < 5.0:  # ~18 km/h
            congestion_level = "high"
        elif avg_speed < 10.0:  # ~36 km/h
            congestion_level = "medium"
        elif density > 50:  # High density but decent speed
            congestion_level = "medium"
        
        self.current_metrics["congestion_level"] = congestion_level
        
        # Additional congestion metrics
        edges_with_congestion = 0
        total_edges = 0
        
        for edge_id in traci_conn.edge.getIDList()[:50]:
            try:
                vehicles = traci_conn.edge.getLastStepVehicleNumber(edge_id)
                total_edges += 1
                
                if vehicles > 10:  # Threshold for congestion
                    edges_with_congestion += 1
            except:
                continue
        
        if total_edges > 0:
            congestion_percentage = (edges_with_congestion / total_edges) * 100
            self.current_metrics["congestion_percentage"] = congestion_percentage
    
    def record_hazard(self, hazard_event):
        """
        Record a hazard event for analytics
        
        Args:
            hazard_event: HazardEvent object
        """
        try:
            hazard_data = {
                "hazard_id": hazard_event.hazard_id,
                "hazard_name": hazard_event.hazard_name,
                "start_time": hazard_event.start_step * self.config["simulation"]["step_length"],
                "duration": hazard_event.duration_steps * self.config["simulation"]["step_length"],
                "affected_vehicles": len(hazard_event.affected_vehicles),
                "priority": hazard_event.priority,
                "metadata": hazard_event.metadata,
                "severity": self._estimate_hazard_severity(hazard_event)
            }
            
            # Add to hazard history
            self.hazard_history.append(hazard_data)
            
            # Update hazard statistics
            self.hazard_stats["total_hazards"] += 1
            self.hazard_stats["hazards_by_type"][hazard_event.hazard_name] += 1
            self.hazard_stats["affected_vehicles"] += len(hazard_event.affected_vehicles)
            self.hazard_stats["hazard_severity"][hazard_data["severity"]] += 1
            
            # Store duration
            self.hazard_stats["hazard_durations"][hazard_event.hazard_name].append(
                hazard_data["duration"]
            )
            
            self.stats["hazards_analyzed"] += 1
            
        except Exception as e:
            print(f"⚠ Error recording hazard: {e}")
    
    def _estimate_hazard_severity(self, hazard_event) -> str:
        """
        Estimate severity of a hazard event
        
        Args:
            hazard_event: HazardEvent object
            
        Returns:
            str: Severity (low, medium, high)
        """
        affected_count = len(hazard_event.affected_vehicles)
        priority = hazard_event.priority
        metadata = hazard_event.metadata
        
        # Base severity on affected vehicles
        if affected_count > 10:
            return "high"
        elif affected_count > 3:
            return "medium"
        
        # Adjust based on hazard type and metadata
        if hazard_event.hazard_name == "ACCIDENT":
            impact = metadata.get("max_impact_factor", 1.0)
            if impact > 2.0:
                return "high"
            elif impact > 1.5:
                return "medium"
        
        elif hazard_event.hazard_name == "EMERGENCY_VEHICLE":
            vehicle_count = metadata.get("vehicle_count", 1)
            if vehicle_count > 2:
                return "high"
        
        return "low"
    
    def _update_hazard_statistics(self):
        """
        Update hazard-related statistics
        """
        self.current_metrics["hazard_count"] = len([
            h for h in self.hazard_history 
            if h.get("start_time", 0) > self.stats.get("last_update", 0) - 300  # Last 5 minutes
        ])
    
    def _store_historical_snapshot(self, timestamp: float):
        """
        Store a historical snapshot of metrics
        
        Args:
            timestamp: Current simulation time
        """
        snapshot = {
            "timestamp": timestamp,
            "metrics": self.current_metrics.copy(),
            "hazard_count": len(self.hazard_history),
            "vehicle_count": self.current_metrics["vehicle_count"]
        }
        
        self.historical_data.append(snapshot)
        
        # Keep only last 1000 snapshots
        if len(self.historical_data) > 1000:
            self.historical_data = self.historical_data[-1000:]
    
    def get_current_metrics(self) -> Dict:
        """
        Get current traffic metrics
        
        Returns:
            Dict: Current metrics
        """
        return self.current_metrics.copy()
    
    def get_hazard_statistics(self) -> Dict:
        """
        Get hazard statistics
        
        Returns:
            Dict: Hazard statistics
        """
        stats = self.hazard_stats.copy()
        
        # Calculate averages
        for hazard_type, durations in stats["hazard_durations"].items():
            if durations:
                stats["hazard_durations"][hazard_type] = {
                    "avg": sum(durations) / len(durations),
                    "min": min(durations),
                    "max": max(durations),
                    "count": len(durations)
                }
        
        return stats
    
    def get_congestion_analysis(self) -> Dict:
        """
        Get congestion analysis
        
        Returns:
            Dict: Congestion analysis
        """
        if not self.density_history:
            return {"level": "unknown", "trend": "stable"}
        
        recent_density = list(self.density_history)[-10:]  # Last 10 readings
        if len(recent_density) < 2:
            return {"level": self.current_metrics["congestion_level"], "trend": "stable"}
        
        # Calculate trend
        if len(recent_density) >= 5:
            first_half = statistics.mean(recent_density[:len(recent_density)//2])
            second_half = statistics.mean(recent_density[len(recent_density)//2:])
            
            if second_half > first_half * 1.1:
                trend = "increasing"
            elif second_half < first_half * 0.9:
                trend = "decreasing"
            else:
                trend = "stable"
        else:
            trend = "stable"
        
        return {
            "level": self.current_metrics["congestion_level"],
            "density": recent_density[-1] if recent_density else 0,
            "trend": trend,
            "percentage": self.current_metrics.get("congestion_percentage", 0)
        }
    
    def get_vehicle_type_analysis(self) -> Dict:
        """
        Get analysis by vehicle type
        
        Returns:
            Dict: Vehicle type analysis
        """
        analysis = {}
        
        for vtype in self.speed_history.keys():
            if vtype == "global":
                continue
            
            speeds = list(self.speed_history[vtype])
            if speeds:
                analysis[vtype] = {
                    "avg_speed": statistics.mean(speeds[-20:]) if len(speeds) >= 20 else statistics.mean(speeds),
                    "min_speed": min(speeds[-50:]) if len(speeds) >= 50 else min(speeds),
                    "max_speed": max(speeds[-50:]) if len(speeds) >= 50 else max(speeds),
                    "sample_count": len(speeds)
                }
        
        return analysis
    
    def get_ml_features(self, window_seconds: int = 60) -> Dict:
        """
        Generate ML features for the specified time window
        
        Args:
            window_seconds: Time window in seconds
            
        Returns:
            Dict: ML features
        """
        step_length = self.config["simulation"]["step_length"]
        window_steps = int(window_seconds / step_length)
        
        # Get recent data
        recent_hazards = list(self.hazard_history)[-window_steps:]
        recent_speeds = list(self.speed_history["global"])[-window_steps:]
        recent_density = list(self.density_history)[-window_steps:]
        
        # Calculate features
        features = {
            # Basic features
            "avg_speed": statistics.mean(recent_speeds) if recent_speeds else 0,
            "speed_std": statistics.stdev(recent_speeds) if len(recent_speeds) > 1 else 0,
            "avg_density": statistics.mean(recent_density) if recent_density else 0,
            
            # Hazard features
            "hazard_count": len(recent_hazards),
            "hazard_frequency": len(recent_hazards) / window_seconds if window_seconds > 0 else 0,
            "emergency_vehicles": self.current_metrics["emergency_vehicles"],
            
            # Traffic flow features
            "congestion_level": 1 if self.current_metrics["congestion_level"] == "high" else 
                              2 if self.current_metrics["congestion_level"] == "medium" else 3,
            "throughput": self.current_metrics["throughput"],
            
            # Temporal features
            "time_of_day": 0,  # Would need real time
            "is_peak_hour": 0,
        }
        
        # Add hazard type counts
        hazard_types = self.config["hazards"]["hazard_priority"].keys()
        for hazard_type in hazard_types:
            count = sum(1 for h in recent_hazards if h.get("hazard_name") == hazard_type)
            features[f"{hazard_type}_count"] = count
        
        # Add interaction features
        if recent_speeds and recent_hazards:
            features["speed_during_hazards"] = statistics.mean(
                [s for s, h in zip(recent_speeds[-len(recent_hazards):], recent_hazards)]
            ) if recent_hazards else features["avg_speed"]
        
        return features
    
    def get_summary(self) -> Dict:
        """
        Get analytics summary
        
        Returns:
            Dict: Summary of analytics
        """
        hazard_stats = self.get_hazard_statistics()
        congestion = self.get_congestion_analysis()
        vehicle_analysis = self.get_vehicle_type_analysis()
        
        summary = {
            "timestamp": self.stats.get("last_update", 0),
            "current_metrics": self.current_metrics,
            "hazard_summary": {
                "total_hazards": hazard_stats["total_hazards"],
                "by_type": dict(hazard_stats["hazards_by_type"]),
                "affected_vehicles": hazard_stats["affected_vehicles"],
                "severity_distribution": dict(hazard_stats["hazard_severity"])
            },
            "congestion": congestion,
            "vehicle_analysis": vehicle_analysis,
            "statistics": self.stats.copy()
        }
        
        # Calculate hazard impact score
        hazard_impact = self._calculate_hazard_impact_score()
        summary["hazard_impact"] = hazard_impact
        
        return summary
    
    def _calculate_hazard_impact_score(self) -> float:
        """
        Calculate overall hazard impact score
        
        Returns:
            float: Impact score (0-1)
        """
        if not self.hazard_history:
            return 0.0
        
        recent_hazards = list(self.hazard_history)[-100:]  # Last 100 hazards
        
        if not recent_hazards:
            return 0.0
        
        total_impact = 0
        max_possible = 0
        
        for hazard in recent_hazards:
            severity = hazard.get("severity", "low")
            affected = hazard.get("affected_vehicles", 1)
            duration = hazard.get("duration", 0)
            
            # Severity weights
            severity_weight = {"low": 0.3, "medium": 0.6, "high": 1.0}.get(severity, 0.3)
            
            # Calculate impact
            impact = severity_weight * min(affected / 10, 1.0) * min(duration / 300, 1.0)
            total_impact += impact
            
            max_possible += 1.0  # Maximum possible per hazard
        
        return total_impact / max_possible if max_possible > 0 else 0.0
    
    def export_data(self, format: str = "json") -> str:
        """
        Export analytics data
        
        Args:
            format: Export format ("json" or "csv")
            
        Returns:
            str: Exported data
        """
        summary = self.get_summary()
        
        if format.lower() == "csv":
            # Convert to CSV format (simplified)
            lines = ["Metric,Value"]
            for category, data in summary.items():
                if isinstance(data, dict):
                    for key, value in data.items():
                        lines.append(f"{category}.{key},{value}")
                else:
                    lines.append(f"{category},{data}")
            return "\n".join(lines)
        
        else:  # JSON
            return json.dumps(summary, indent=2, default=str)
    
    def reset(self):
        """Reset analytics data"""
        self.speed_history.clear()
        self.acceleration_history.clear()
        self.density_history.clear()
        self.flow_history.clear()
        self.hazard_history.clear()
        self.historical_data.clear()
        
        self.current_metrics = {
            "avg_speed": 0.0,
            "avg_acceleration": 0.0,
            "congestion_level": "low",
            "hazard_count": 0,
            "vehicle_count": 0,
            "emergency_vehicles": 0,
            "throughput": 0.0,
            "avg_travel_time": 0.0
        }
        
        self.hazard_stats = {
            "total_hazards": 0,
            "hazards_by_type": defaultdict(int),
            "hazard_durations": defaultdict(list),
            "affected_vehicles": 0,
            "hazard_severity": defaultdict(int)
        }
        
        self.stats = {
            "updates": 0,
            "data_points": 0,
            "hazards_analyzed": 0,
            "last_update": None
        }


# Test function
def test_traffic_analytics():
    """Test traffic analytics functionality"""
    print("Testing Traffic Analytics...")
    
    # Create test config
    test_config = {
        "simulation": {
            "step_length": 0.1
        },
        "network": {
            "default_speed": 50.0
        },
        "hazards": {
            "hazard_priority": {
                "ACCIDENT": 1,
                "EMERGENCY_VEHICLE": 2
            }
        },
        "traffic_analytics": {
            "window_size_seconds": 60,
            "window_step_seconds": 10
        }
    }
    
    # Create analytics
    analytics = TrafficAnalytics(test_config)
    
    print(f"✓ Analytics initialized")
    print(f"  Window size: {analytics.window_size}s")
    print(f"  Window step: {analytics.window_step}s")
    
    # Test getting empty summary
    summary = analytics.get_summary()
    print(f"  Initial summary: {len(summary)} items")
    
    # Test ML features
    features = analytics.get_ml_features(30)
    print(f"  ML features: {len(features)} features")
    
    print("Test completed!")


if __name__ == "__main__":
    test_traffic_analytics()