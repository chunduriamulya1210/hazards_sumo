"""
VEHICLE SENSOR - Mumbai Traffic Simulation
Collects vehicle data for CSV output and hazard detection
"""

import traci
from typing import Dict, List, Optional, Set, Any
import random
import math
from collections import defaultdict


class VehicleSensor:
    """
    Collects sensor data from vehicles for CSV output and analytics
    """
    
    def __init__(self, config: Dict):
        """
        Initialize vehicle sensor system
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        
        # Default sensor parameters
        self.update_interval = 1  # Update every step
        self.max_vehicles_per_step = 200  # Max vehicles to sample per step
        
        # Data collection filters
        self.collect_only_moving = False
        self.min_speed_threshold = 0.5  # m/s
        self.collect_all_during_hazards = True
        
        # Hazard tracking
        self.active_hazards: Set[str] = set()
        self.hazard_vehicles: Dict[str, Set[str]] = {}  # hazard_name -> vehicle_ids
        
        # Statistics
        self.stats = {
            "total_readings": 0,
            "vehicles_sampled": 0,
            "hazard_readings": 0,
            "last_update_step": 0
        }
        
        # Previous speeds for acceleration calculation
        self._prev_speeds = {}
        
        print(f"Vehicle Sensor initialized:")
        print(f"  Update interval: {self.update_interval} steps")
        print(f"  Max vehicles per step: {self.max_vehicles_per_step}")
    
    def collect_data(self, traci_conn, simulation_state: Dict) -> List[Dict]:
        """
        Collect sensor data from vehicles
        
        Args:
            traci_conn: TraCI connection
            simulation_state: Current simulation state
            
        Returns:
            List[Dict]: List of vehicle sensor readings
        """
        current_step = simulation_state.get("step", 0)
        
        # Check if we should collect data this step
        if current_step % self.update_interval != 0:
            return []
        
        vehicle_ids = traci_conn.vehicle.getIDList()
        if not vehicle_ids:
            return []
        
        # Determine which vehicles to sample
        vehicles_to_sample = self._select_vehicles_to_sample(
            vehicle_ids, traci_conn, simulation_state
        )
        
        # Collect data from selected vehicles
        sensor_readings = []
        for veh_id in vehicles_to_sample:
            try:
                reading = self._collect_vehicle_data(veh_id, traci_conn, simulation_state)
                if reading:
                    sensor_readings.append(reading)
                    self.stats["total_readings"] += 1
            except Exception as e:
                # Silently skip vehicles that cause errors
                continue
        
        self.stats["vehicles_sampled"] += len(sensor_readings)
        self.stats["last_update_step"] = current_step
        
        return sensor_readings
    
    def _select_vehicles_to_sample(self, vehicle_ids: List[str], traci_conn, 
                                  simulation_state: Dict) -> List[str]:
        """
        Select which vehicles to sample this step
        
        Args:
            vehicle_ids: All vehicle IDs
            traci_conn: TraCI connection
            simulation_state: Simulation state
            
        Returns:
            List[str]: Vehicle IDs to sample
        """
        if not vehicle_ids:
            return []
        
        # During active hazards, sample more vehicles
        if self.active_hazards and self.collect_all_during_hazards:
            # Get all vehicles involved in hazards + random sample
            hazard_vehicles = set()
            for vehicles in self.hazard_vehicles.values():
                hazard_vehicles.update(vehicles)
            
            # Add hazard vehicles first
            selected = list(hazard_vehicles)
            
            # Add random sample of other vehicles
            other_vehicles = [v for v in vehicle_ids if v not in hazard_vehicles]
            if other_vehicles:
                sample_size = min(
                    self.max_vehicles_per_step - len(selected),
                    max(10, len(other_vehicles) // 10)
                )
                if sample_size > 0:
                    selected.extend(random.sample(other_vehicles, 
                                                min(sample_size, len(other_vehicles))))
            
            return selected
        
        # Normal sampling: prioritize vehicles in certain conditions
        prioritized = []
        regular = []
        
        for veh_id in vehicle_ids[:self.max_vehicles_per_step * 2]:  # Check more than we need
            try:
                # Check if vehicle is interesting
                speed = traci_conn.vehicle.getSpeed(veh_id)
                vtype = traci_conn.vehicle.getTypeID(veh_id)
                
                # Skip stationary vehicles if configured
                if self.collect_only_moving and speed < self.min_speed_threshold:
                    continue
                
                # Prioritize certain vehicles
                is_priority = (
                    vtype == "emergency" or
                    speed > 20 or  # Fast vehicles
                    speed < 2 or   # Slow/stopped vehicles
                    self._is_at_intersection(veh_id, traci_conn) or
                    self._has_hazard_parameter(veh_id, traci_conn)
                )
                
                if is_priority:
                    prioritized.append(veh_id)
                else:
                    regular.append(veh_id)
                    
            except:
                continue
        
        # Combine prioritized and regular vehicles
        if len(prioritized) >= self.max_vehicles_per_step:
            return prioritized[:self.max_vehicles_per_step]
        
        selected = prioritized
        remaining = self.max_vehicles_per_step - len(selected)
        
        if regular and remaining > 0:
            sample_size = min(remaining, len(regular))
            selected.extend(random.sample(regular, sample_size))
        
        return selected
    
    def _collect_vehicle_data(self, veh_id: str, traci_conn, 
                             simulation_state: Dict) -> Optional[Dict]:
        """
        Collect data from a single vehicle
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            simulation_state: Simulation state
            
        Returns:
            Dict: Vehicle sensor data or None if collection fails
        """
        try:
            # Basic vehicle information
            vtype = traci_conn.vehicle.getTypeID(veh_id)
            speed = traci_conn.vehicle.getSpeed(veh_id)
            position = traci_conn.vehicle.getPosition(veh_id)
            lane_id = traci_conn.vehicle.getLaneID(veh_id)
            lane_index = traci_conn.vehicle.getLaneIndex(veh_id)
            lane_pos = traci_conn.vehicle.getLanePosition(veh_id)
            
            # Edge information
            edge_id = ""
            if lane_id:
                try:
                    edge_id = traci_conn.lane.getEdgeID(lane_id)
                except:
                    pass
            
            # Acceleration (approximate from speed change)
            acceleration = self._estimate_acceleration(veh_id, traci_conn, speed)
            
            # Distance to leader
            leader_info = traci_conn.vehicle.getLeader(veh_id, 200)
            gap_to_leader = leader_info[1] if leader_info else -1
            
            # Signal state
            signal_state = self._get_signal_state(veh_id, traci_conn)
            
            # Hazard detection
            hazard_type, hazard_severity = self._detect_hazards(veh_id, traci_conn, speed, acceleration)
            
            # RSU ID (simulated - based on position)
            rsu_id = self._get_rsu_id(position, simulation_state)
            
            # Additional metrics
            lateral_speed = 0
            waiting_time = 0
            co2_emission = 0
            
            try:
                lateral_speed = traci_conn.vehicle.getLateralSpeed(veh_id)
                waiting_time = traci_conn.vehicle.getWaitingTime(veh_id)
                co2_emission = traci_conn.vehicle.getCO2Emission(veh_id)
            except:
                pass
            
            # Build sensor reading
            reading = {
                "vehicle_id": veh_id,
                "vehicle_type": vtype,
                "x": position[0] if position else 0,
                "y": position[1] if position else 0,
                "speed": speed,
                "acceleration": acceleration,
                "lane_id": lane_id,
                "lane_index": lane_index,
                "lane_position": lane_pos,
                "edge_id": edge_id,
                "gap_to_leader": gap_to_leader,
                "signal_state": signal_state,
                "hazard_type": hazard_type,
                "hazard_severity": hazard_severity,
                "rsu_id": rsu_id,
                "lateral_speed": lateral_speed,
                "waiting_time": waiting_time,
                "co2_emission": co2_emission,
                "timestamp": simulation_state.get("simulation_time", 0),
                "simulation_step": simulation_state.get("step", 0)
            }
            
            # Add vehicle parameters that indicate hazards
            self._add_hazard_parameters(veh_id, traci_conn, reading)
            
            return reading
            
        except Exception as e:
            # Failed to collect data from this vehicle
            return None
    
    def _estimate_acceleration(self, veh_id: str, traci_conn, current_speed: float) -> float:
        """
        Estimate vehicle acceleration
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            current_speed: Current speed
            
        Returns:
            float: Estimated acceleration (m/s²)
        """
        try:
            # Try to get acceleration directly
            return traci_conn.vehicle.getAcceleration(veh_id)
        except:
            # Fallback: approximate from speed
            prev_speed = self._prev_speeds.get(veh_id, current_speed)
            
            # Simple estimation (assuming 0.1s step length)
            step_length = self.config["simulation"]["step_length"]
            acceleration = (current_speed - prev_speed) / step_length
            
            # Update stored speed
            self._prev_speeds[veh_id] = current_speed
            
            return acceleration
    
    def _get_signal_state(self, veh_id: str, traci_conn) -> str:
        """
        Get traffic signal state for vehicle
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            
        Returns:
            str: Signal state (RED, YELLOW, GREEN, N/A)
        """
        try:
            tls_list = traci_conn.vehicle.getNextTLS(veh_id)
            if not tls_list:
                return "N/A"
            
            tls_id, link_index, dist = tls_list[0]
            
            # Only consider if close to intersection
            if dist > 50:  # meters
                return "N/A"
            
            state = traci_conn.trafficlight.getRedYellowGreenState(tls_id)
            if link_index < len(state):
                signal_char = state[link_index]
                if signal_char == 'r' or signal_char == 'R':
                    return "RED"
                elif signal_char == 'y' or signal_char == 'Y':
                    return "YELLOW"
                elif signal_char == 'g' or signal_char == 'G':
                    return "GREEN"
            
            return "N/A"
        except:
            return "N/A"
    
    def _detect_hazards(self, veh_id: str, traci_conn, speed: float, acceleration: float) -> tuple:
        """
        Detect hazards for a vehicle
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            speed: Current speed
            acceleration: Current acceleration
            
        Returns:
            tuple: (hazard_type, hazard_severity)
        """
        hazard_type = "NORMAL"
        hazard_severity = "low"
        
        try:
            # Check for hazard parameters
            hazard_params = [
                "hazard.emergency",
                "hazard.wrong_way", 
                "hazard.ignore_red_light",
                "hazard.accident",
                "hazard.tailgating",
                "hazard.overspeeding"
            ]
            
            for param in hazard_params:
                value = traci_conn.vehicle.getParameter(veh_id, param)
                if value and value.lower() == "true":
                    # Extract hazard type from parameter name
                    hazard_name = param.split('.')[1].upper()
                    if hazard_name == "EMERGENCY":
                        hazard_type = "EMERGENCY_VEHICLE"
                    elif hazard_name == "ACCIDENT":
                        hazard_type = "ACCIDENT"
                    else:
                        hazard_type = hazard_name
                    
                    # Estimate severity
                    hazard_severity = self._estimate_hazard_severity(
                        veh_id, hazard_name, traci_conn
                    )
                    break
            
            # Check for unusual behavior (additional hazard detection)
            if hazard_type == "NORMAL":
                vtype = traci_conn.vehicle.getTypeID(veh_id)
                
                # Check for speeding relative to type
                if "vehicle_types" in self.config and vtype in self.config["vehicle_types"]:
                    type_config = self.config["vehicle_types"][vtype]
                    max_speed = type_config.get("max_speed", 80)
                    max_speed_ms = max_speed / 3.6
                    
                    if speed > max_speed_ms * 1.3:  # 30% over limit
                        hazard_type = "SPEEDING"
                        hazard_severity = "high" if speed > max_speed_ms * 1.5 else "medium"
                
                # Check for sudden deceleration (braking)
                if acceleration < -4.0:  # Hard braking
                    hazard_type = "SUDDEN_BRAKING"
                    hazard_severity = "high" if acceleration < -6.0 else "medium"
            
        except Exception:
            pass
        
        return hazard_type, hazard_severity
    
    def _estimate_hazard_severity(self, veh_id: str, hazard_type: str, 
                                 traci_conn) -> str:
        """
        Estimate severity of a hazard
        
        Args:
            veh_id: Vehicle ID
            hazard_type: Type of hazard
            traci_conn: TraCI connection
            
        Returns:
            str: Severity (low, medium, high)
        """
        try:
            if hazard_type == "ACCIDENT":
                speed = traci_conn.vehicle.getSpeed(veh_id)
                return "high" if speed < 1.0 else "medium"
            
            elif hazard_type == "SPEEDING":
                speed = traci_conn.vehicle.getSpeed(veh_id)
                vtype = traci_conn.vehicle.getTypeID(veh_id)
                
                if "vehicle_types" in self.config and vtype in self.config["vehicle_types"]:
                    type_config = self.config["vehicle_types"][vtype]
                    max_speed = type_config.get("max_speed", 80) / 3.6
                    
                    if speed > max_speed * 1.5:
                        return "high"
                    elif speed > max_speed * 1.3:
                        return "medium"
                
                return "low"
            
            elif hazard_type == "TAILGATING":
                leader_info = traci_conn.vehicle.getLeader(veh_id, 50)
                if leader_info:
                    gap = leader_info[1]
                    min_gap = traci_conn.vehicle.getMinGap(veh_id)
                    
                    if gap < min_gap * 0.3:
                        return "high"
                    elif gap < min_gap * 0.5:
                        return "medium"
                
                return "low"
            
            else:
                return "medium"  # Default for other hazards
        
        except:
            return "low"
    
    def _get_rsu_id(self, position: tuple, simulation_state: Dict) -> str:
        """
        Simulate RSU ID based on vehicle position
        
        Args:
            position: (x, y) coordinates
            simulation_state: Simulation state
            
        Returns:
            str: Simulated RSU ID
        """
        # Simple grid-based RSU assignment
        if not position:
            return "RSU_0"
        
        x, y = position
        
        # Create grid cells (100m x 100m)
        grid_x = int(x / 100)
        grid_y = int(y / 100)
        
        # Limit to reasonable range
        grid_x = max(0, min(99, grid_x))
        grid_y = max(0, min(99, grid_y))
        
        return f"RSU_{grid_x}_{grid_y}"
    
    def _is_at_intersection(self, veh_id: str, traci_conn) -> bool:
        """
        Check if vehicle is near an intersection
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            
        Returns:
            bool: True if near intersection
        """
        try:
            tls_list = traci_conn.vehicle.getNextTLS(veh_id)
            if not tls_list:
                return False
            
            # Check distance to nearest traffic light
            _, _, dist = tls_list[0]
            return dist < 30  # meters
        except:
            return False
    
    def _has_hazard_parameter(self, veh_id: str, traci_conn) -> bool:
        """
        Check if vehicle has any hazard parameter set
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            
        Returns:
            bool: True if has hazard parameter
        """
        try:
            hazard_params = [
                "hazard.emergency", "hazard.wrong_way", "hazard.ignore_red_light",
                "hazard.accident", "hazard.tailgating", "hazard.overspeeding"
            ]
            
            for param in hazard_params:
                value = traci_conn.vehicle.getParameter(veh_id, param)
                if value and value.lower() == "true":
                    return True
            
            return False
        except:
            return False
    
    def _add_hazard_parameters(self, veh_id: str, traci_conn, reading: Dict):
        """
        Add hazard parameters to reading
        
        Args:
            veh_id: Vehicle ID
            traci_conn: TraCI connection
            reading: Sensor reading dictionary
        """
        try:
            hazard_params = {}
            
            for param in [
                "hazard.emergency", "hazard.wrong_way", "hazard.ignore_red_light",
                "hazard.accident", "hazard.tailgating", "hazard.overspeeding",
                "hazard.aggressive_lane_change", "hazard.sudden_braking"
            ]:
                value = traci_conn.vehicle.getParameter(veh_id, param)
                if value:
                    param_name = param.split('.')[1]
                    hazard_params[param_name] = value
            
            if hazard_params:
                reading["hazard_parameters"] = hazard_params
                
        except:
            pass
    
    def record_hazard(self, hazard_event):
        """
        Record a hazard event for focused sampling
        
        Args:
            hazard_event: HazardEvent object
        """
        try:
            hazard_name = hazard_event.hazard_name
            affected_vehicles = hazard_event.affected_vehicles
            
            self.active_hazards.add(hazard_name)
            
            if hazard_name not in self.hazard_vehicles:
                self.hazard_vehicles[hazard_name] = set()
            
            self.hazard_vehicles[hazard_name].update(affected_vehicles)
            self.stats["hazard_readings"] += len(affected_vehicles)
        except:
            pass
    
    def clear_expired_hazards(self, simulation_state: Dict):
        """
        Clear expired hazards from tracking
        
        Args:
            simulation_state: Current simulation state
        """
        # Simplified: clear all hazards periodically
        current_step = simulation_state.get("step", 0)
        
        if current_step % 100 == 0:  # Clear every 100 steps
            self.active_hazards.clear()
            self.hazard_vehicles.clear()
    
    def get_statistics(self) -> Dict:
        """
        Get sensor statistics
        
        Returns:
            Dict: Statistics dictionary
        """
        return self.stats.copy()
    
    def reset_statistics(self):
        """Reset sensor statistics"""
        self.stats = {
            "total_readings": 0,
            "vehicles_sampled": 0,
            "hazard_readings": 0,
            "last_update_step": 0
        }


# Test function
def test_vehicle_sensor():
    """Test vehicle sensor functionality"""
    print("Testing Vehicle Sensor...")
    
    # Create test config
    test_config = {
        "simulation": {
            "step_length": 0.1
        },
        "vehicle_types": {
            "motorcycle": {"max_speed": 80.0},
            "passenger": {"max_speed": 100.0}
        }
    }
    
    # Create sensor
    sensor = VehicleSensor(test_config)
    
    print(f"✓ Sensor initialized")
    print(f"  Update interval: {sensor.update_interval}")
    print(f"  Max vehicles: {sensor.max_vehicles_per_step}")
    
    # Test statistics
    stats = sensor.get_statistics()
    print(f"  Initial stats: {stats}")
    
    print("Test completed!")


if __name__ == "__main__":
    test_vehicle_sensor()