"""
SIMULATION ENGINE - Mumbai Traffic Simulation
Main simulation loop with hazard integration
Compatible with updated HazardManager and config
"""

import os
import sys
import time
import random
import traci
import sumolib
from typing import Dict, List, Optional, Tuple
from datetime import datetime

# Local imports
try:
    from config_loader import load_config
    from hazard_manager import HazardManager, HazardEvent
    from network_manager import NetworkManager
    from vehicle_system import VehicleSystem
    from vehicle_sensor import VehicleSensor
    from traffic_analytics import TrafficAnalytics
    from csv_writer import CSVWriter
except ImportError as e:
    print(f"Import error: {e}")
    print("Please make sure all required files are in the same directory:")
    print("1. config_loader.py")
    print("2. hazard_manager.py")
    print("3. network_manager.py")
    print("4. vehicle_system.py")
    print("5. vehicle_sensor.py")
    print("6. traffic_analytics.py")
    print("7. csv_writer.py")
    sys.exit(1)


class SimulationEngine:
    """
    Main simulation engine for Mumbai traffic with hazard integration
    """
    
    def __init__(self, config_path: str = "config.json"):
        """
        Initialize simulation engine
        
        Args:
            config_path: Path to configuration JSON file
        """
        print("=" * 60)
        print("MUMBAI TRAFFIC SIMULATION ENGINE")
        print("=" * 60)
        
        # Load configuration
        self.config = load_config(config_path)
        print(f"✓ Configuration loaded from {config_path}")
        print(f"  Mode: {self.config['simulation']['mode']}")
        print(f"  City: {self.config['simulation']['city']}")
        print(f"  Duration: {self.config['simulation']['duration_seconds']} seconds")
        
        # Set random seed for reproducibility
        if 'seed' in self.config['simulation']:
            random.seed(self.config['simulation']['seed'])
            print(f"  Random seed: {self.config['simulation']['seed']}")
        
        # Initialize components
        self.simulation_state = {
            'step': 0,
            'total_vehicles': 0,
            'edges_with_traffic': [],
            'edge_to_lanes': {},
            'simulation_time': 0.0
        }
        
        # Core systems
        self.network_manager = None
        self.vehicle_system = None
        self.vehicle_sensor = None
        self.hazard_manager = None
        self.traffic_analytics = None
        self.csv_writer = None
        
        # Statistics
        self.stats = {
            'total_steps': 0,
            'vehicles_spawned': 0,
            'vehicles_despawned': 0,
            'hazards_triggered': 0,
            'hazard_events': [],
            'start_time': None,
            'end_time': None
        }
        
        print("✓ Simulation engine initialized")
        
    def initialize_simulation(self):
        """
        Initialize SUMO and all simulation components
        """
        print("\n" + "=" * 60)
        print("INITIALIZING SIMULATION COMPONENTS")
        print("=" * 60)
        
        try:
            # 1. Initialize SUMO
            self._initialize_sumo()
            
            # 2. Initialize network manager
            self.network_manager = NetworkManager(self.config)
            self.network_manager.initialize(traci)
            print("✓ Network manager initialized")
            
            # 3. Initialize vehicle system
            self.vehicle_system = VehicleSystem(self.config)
            print("✓ Vehicle system initialized")
            
            # 4. Initialize vehicle sensor system
            self.vehicle_sensor = VehicleSensor(self.config)
            print("✓ Vehicle sensor system initialized")
            
            # 5. Initialize hazard manager
            self.hazard_manager = HazardManager(self.config)
            print("✓ Hazard manager initialized (10 hazard types)")
            
            # 6. Initialize traffic analytics
            self.traffic_analytics = TrafficAnalytics(self.config)
            print("✓ Traffic analytics initialized")
            
            # 7. Initialize CSV writer
            self.csv_writer = CSVWriter(self.config)
            if not self.csv_writer.initialize_files():
                raise Exception("Failed to initialize CSV files")
            print("✓ CSV writer initialized with append mode and sliding windows")
            
            # 8. Warm-up phase if configured
            warmup_seconds = self.config['simulation'].get('warmup_seconds', 0)
            if warmup_seconds > 0:
                print(f"\n🔥 Warming up simulation for {warmup_seconds} seconds...")
                self._warmup_simulation(warmup_seconds)
            
            print("=" * 60)
            print("ALL COMPONENTS INITIALIZED SUCCESSFULLY")
            print("=" * 60)
            
            self.stats['start_time'] = datetime.now()
            
        except Exception as e:
            print(f"❌ Failed to initialize simulation: {e}")
            self.cleanup()
            raise
    
    def _initialize_sumo(self):
        """
        Initialize SUMO connection
        """
        print("Initializing SUMO connection...")
        
        # SUMO configuration
        sumo_binary = self.config['simulation'].get('sumo_binary', 'sumo')
        net_file = self.config['simulation']['net_file']
        route_file = self.config['simulation']['route_file']
        additional_file = self.config['simulation']['additional_file']
        gui = self.config['simulation'].get('gui', False)
        port = self.config['simulation'].get('port', 8813)
        
        # Build SUMO command
        sumo_cmd = [
            sumo_binary,
            '-n', net_file,
            '-r', route_file,
            '-a', additional_file,
            '--step-length', str(self.config['simulation']['step_length']),
            '--time-to-teleport', '300',
            '--collision.action', 'warn',
            '--collision.check-junctions', 'true',
            '--random'
        ]
        
        if not gui:
            sumo_cmd.append('--no-warnings')
        
        # Add port if specified
        if port:
            sumo_cmd.extend(['--remote-port', str(port)])
        
        print(f"SUMO command: {' '.join(sumo_cmd)}")
        
        # Start SUMO
        traci.start(sumo_cmd)
        print("✓ SUMO connection established")
        
        # Set simulation parameters
        traci.simulation.setScale(1.0)
        
    def _warmup_simulation(self, warmup_seconds: int):
        """
        Run simulation warmup phase
        
        Args:
            warmup_seconds: Duration of warmup in seconds
        """
        step_length = self.config['simulation']['step_length']
        warmup_steps = int(warmup_seconds / step_length)
        
        for step in range(warmup_steps):
            traci.simulationStep()
            
            # Update vehicle system during warmup
            if self.vehicle_system:
                self.vehicle_system.update(traci, step)
        
        print(f"✓ Warmup completed: {warmup_steps} steps")
        
    def run_simulation(self):
        """
        Main simulation loop
        """
        print("\n" + "=" * 60)
        print("STARTING SIMULATION")
        print("=" * 60)
        
        try:
            # Get simulation parameters
            duration_seconds = self.config['simulation']['duration_seconds']
            step_length = self.config['simulation']['step_length']
            total_steps = int(duration_seconds / step_length)
            
            print(f"Simulation parameters:")
            print(f"  Duration: {duration_seconds} seconds")
            print(f"  Step length: {step_length} seconds")
            print(f"  Total steps: {total_steps}")
            print(f"  Max vehicles: {self.config['simulation']['max_vehicles']}")
            print()
            
            # Main simulation loop
            for step in range(total_steps):
                # Execute simulation step
                self._execute_step(step)
                
                # Display progress every 100 steps
                if step % 100 == 0:
                    vehicles = len(traci.vehicle.getIDList())
                    time_seconds = step * step_length
                    print(f"  Step {step:6d} | Time: {time_seconds:6.1f}s | Vehicles: {vehicles:4d}")
            
            print("\n" + "=" * 60)
            print("SIMULATION COMPLETED SUCCESSFULLY")
            print("=" * 60)
            
            self.stats['end_time'] = datetime.now()
            self._print_final_stats()
            
        except Exception as e:
            print(f"\n❌ Simulation error at step {self.simulation_state['step']}: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            self.cleanup()
    
    def _execute_step(self, step: int):
        """
        Execute a single simulation step
        
        Args:
            step: Current simulation step
        """
        # Update simulation state
        self.simulation_state['step'] = step
        self.simulation_state['simulation_time'] = step * self.config['simulation']['step_length']
        self.simulation_state['total_vehicles'] = len(traci.vehicle.getIDList())
        
        # 1. Perform SUMO simulation step
        traci.simulationStep()
        
        # 2. Update network manager
        if self.network_manager:
            self.network_manager.update(traci, self.simulation_state)
        
        # 3. Update vehicle system (spawn/despawn vehicles)
        if self.vehicle_system:
            self.vehicle_system.update(traci, step)
            # Track spawned/despawned vehicles
            current_vehicles = len(traci.vehicle.getIDList())
            # This is simplified - you'd want better tracking
            if hasattr(self.vehicle_system, 'get_spawned_count'):
                self.stats['vehicles_spawned'] += self.vehicle_system.get_spawned_count()
            if hasattr(self.vehicle_system, 'get_despawned_count'):
                self.stats['vehicles_despawned'] += self.vehicle_system.get_despawned_count()
        
        # 4. Update edge information for hazards (optimization)
        if step % 10 == 0:  # Update every 10 steps for efficiency
            self._update_edge_information()
        
        # 5. Trigger hazards
        if self.hazard_manager:
            triggered_events = self.hazard_manager.trigger_hazards(
                traci, 
                self.simulation_state
            )
            
            # Process triggered hazards
            for event in triggered_events:
                self._process_hazard_event(event)
                self.stats['hazards_triggered'] += 1
                self.stats['hazard_events'].append(event)
                
                # Write hazard event to CSV
                if self.csv_writer:
                    hazard_event_dict = {
                        "hazard_name": event.hazard_name,
                        "timestamp": self.simulation_state['simulation_time'],
                        "metadata": event.metadata
                    }
                    self.csv_writer.write_hazard_event(hazard_event_dict)
        
        # 6. Clear expired hazards
        if self.hazard_manager:
            self.hazard_manager.clear_expired_events(traci, self.simulation_state)
            self.hazard_manager.periodic_clear_hazards(traci, self.simulation_state)
        
        # 7. Collect sensor data
        if self.vehicle_sensor:
            sensor_data = self.vehicle_sensor.collect_data(traci, self.simulation_state)
            
            # Write to CSV if configured
            if self.csv_writer and sensor_data:
                self.csv_writer.write_data(sensor_data, self.simulation_state)
        
        # 8. Update analytics
        if self.traffic_analytics:
            self.traffic_analytics.update(traci, self.simulation_state)
        
        # 9. Update statistics
        self.stats['total_steps'] += 1
        
        # 10. Check for real-time monitoring
        if self.config['simulation'].get('real_time_monitoring', False):
            if step % 50 == 0:  # Update every 50 steps
                self._display_real_time_stats()
    
    def _update_edge_information(self):
        """
        Update edge information for hazard optimization
        """
        try:
            # Get edges with traffic
            edges_with_traffic = []
            edge_to_lanes = {}
            
            for edge_id in traci.edge.getIDList():
                if ":" not in edge_id:  # Skip internal edges
                    vehicle_count = traci.edge.getLastStepVehicleNumber(edge_id)
                    if vehicle_count > 0:
                        edges_with_traffic.append(edge_id)
                        
                        # Get lanes for this edge
                        lanes = []
                        lane_index = 0
                        while True:
                            lane_id = f"{edge_id}_{lane_index}"
                            try:
                                traci.lane.getLength(lane_id)
                                lanes.append(lane_id)
                                lane_index += 1
                            except:
                                break
                        
                        if lanes:
                            edge_to_lanes[edge_id] = lanes
            
            self.simulation_state['edges_with_traffic'] = edges_with_traffic
            self.simulation_state['edge_to_lanes'] = edge_to_lanes
            
        except Exception as e:
            # Silently fail - this is optimization only
            pass
    
    def _process_hazard_event(self, event: HazardEvent):
        """
        Process a triggered hazard event
        
        Args:
            event: HazardEvent object
        """
        print(f"  🚨 HAZARD TRIGGERED: {event.hazard_name} "
              f"(Priority: {event.priority}, Vehicles: {len(event.affected_vehicles)})")
        
        # Log event details
        if self.config['simulation'].get('verbose', False):
            print(f"    Start: step {event.start_step}")
            print(f"    Duration: {event.duration_steps} steps")
            print(f"    Metadata: {event.metadata.get('type', 'unknown')}")
        
        # Update analytics
        if self.traffic_analytics:
            self.traffic_analytics.record_hazard(event)
        
        # Update sensor system
        if self.vehicle_sensor:
            self.vehicle_sensor.record_hazard(event)
    
    def _display_real_time_stats(self):
        """
        Display real-time simulation statistics
        """
        vehicles = len(traci.vehicle.getIDList())
        time_seconds = self.simulation_state['step'] * self.config['simulation']['step_length']
        
        # Get active hazards
        active_hazards = []
        if self.hazard_manager:
            active_hazards = self.hazard_manager.get_active_hazards()
        
        print(f"\n[Real-Time Stats] Time: {time_seconds:6.1f}s | "
              f"Vehicles: {vehicles:4d} | "
              f"Hazards: {len(active_hazards)}")
        
        if active_hazards:
            for hazard in active_hazards[:3]:  # Show first 3
                print(f"  • {hazard['hazard_name']}: {hazard['affected_vehicles']} vehicles")
            if len(active_hazards) > 3:
                print(f"  ... and {len(active_hazards) - 3} more")
    
    def _print_final_stats(self):
        """
        Print final simulation statistics
        """
        duration = (self.stats['end_time'] - self.stats['start_time']).total_seconds()
        
        print("\n" + "=" * 60)
        print("SIMULATION STATISTICS")
        print("=" * 60)
        print(f"Total simulation time: {duration:.2f} seconds")
        print(f"Total steps executed: {self.stats['total_steps']}")
        print(f"Vehicles spawned: {self.stats['vehicles_spawned']}")
        print(f"Vehicles despawned: {self.stats['vehicles_despawned']}")
        print(f"Hazards triggered: {self.stats['hazards_triggered']}")
        
        # Hazard breakdown
        if self.stats['hazard_events']:
            print("\nHazard Breakdown:")
            hazard_counts = {}
            for event in self.stats['hazard_events']:
                name = event.hazard_name
                hazard_counts[name] = hazard_counts.get(name, 0) + 1
            
            for name, count in sorted(hazard_counts.items()):
                print(f"  {name}: {count}")
        
        # Analytics summary
        if self.traffic_analytics:
            analytics_summary = self.traffic_analytics.get_summary()
            if analytics_summary:
                print(f"\nTraffic Analytics:")
                print(f"  Average speed: {analytics_summary.get('avg_speed', 0):.2f} m/s")
                print(f"  Congestion level: {analytics_summary.get('congestion_level', 'low')}")
                print(f"  Hazard impact score: {analytics_summary.get('hazard_impact', 0):.2f}")
        
        # CSV statistics
        if self.csv_writer:
            csv_stats = self.csv_writer.get_statistics()
            print(f"\nCSV Output:")
            print(f"  Events written: {csv_stats.get('events_written', 0)}")
            print(f"  Windows written: {csv_stats.get('windows_written', 0)}")
        
        print("=" * 60)
    
    def cleanup(self):
        """
        Clean up simulation resources
        """
        print("\nCleaning up simulation resources...")
        
        try:
            # Clear all hazards first
            if self.hazard_manager:
                self.hazard_manager.clear_all_hazards(traci)
                print("✓ Hazards cleared")
            
            # Close CSV writer
            if self.csv_writer:
                self.csv_writer.close()
                print("✓ CSV writer closed")
            
            # Close SUMO connection
            traci.close()
            print("✓ SUMO connection closed")
            
        except Exception as e:
            print(f"⚠ Warning during cleanup: {e}")
        
        print("✓ Cleanup completed")


def main():
    """
    Main entry point for simulation
    """
    print("Mumbai Traffic Simulation - Starting...")
    
    # Check for config file argument
    config_path = "config.json"
    if len(sys.argv) > 1:
        config_path = sys.argv[1]
    
    # Check if config exists
    if not os.path.exists(config_path):
        print(f"❌ Config file not found: {config_path}")
        print(f"Please ensure config.json exists in the current directory")
        return
    
    try:
        # Create and run simulation
        simulator = SimulationEngine(config_path)
        simulator.initialize_simulation()
        simulator.run_simulation()
        
        print("\n🎉 Simulation finished successfully!")
        
    except KeyboardInterrupt:
        print("\n\n⚠ Simulation interrupted by user")
        
    except Exception as e:
        print(f"\n❌ Simulation failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()