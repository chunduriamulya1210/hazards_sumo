"""
VEHICLE SYSTEM - Mumbai Traffic Simulation
Manages vehicle generation, spawning, and lifecycle
Compatible with Mumbai traffic patterns
"""

import random
import traci
from typing import Dict, List, Optional, Set, Tuple
import math
import time
from collections import defaultdict


class VehicleSystem:
    """
    Manages vehicle generation and lifecycle in Mumbai traffic simulation
    """
    
    def __init__(self, config: Dict):
        """
        Initialize vehicle system
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.vehicle_config = config.get("vehicle_generation", {})
        self.vehicle_types = config.get("vehicle_types", {})
        
        # Vehicle generation parameters
        self.vehicle_flow_per_hour = self.vehicle_config.get("vehicle_flow_per_hour", 3000)
        self.spawn_interval_mean = self.vehicle_config.get("spawn_interval_mean", 1.0)
        self.spawn_interval_std = self.vehicle_config.get("spawn_interval_std", 0.2)
        
        # Depart parameters
        self.depart_pos = self.vehicle_config.get("depart_pos", "random")
        self.depart_speed = self.vehicle_config.get("depart_speed", "random")
        self.depart_lane = self.vehicle_config.get("depart_lane", "best")
        
        # Maximum vehicles
        self.max_vehicles = config["simulation"].get("max_vehicles", 12000)
        
        # Vehicle tracking
        self.spawned_vehicles: Set[str] = set()
        self.active_vehicles: Set[str] = set()
        self.vehicle_type_counts = defaultdict(int)
        self.vehicle_routes = {}  # vehicle_id -> route_id
        
        # Spawn timing
        self.last_spawn_time = 0
        self.next_spawn_interval = self._calculate_spawn_interval()
        
        # Statistics
        self.stats = {
            "total_spawned": 0,
            "total_despawned": 0,
            "current_count": 0,
            "max_concurrent": 0,
            "spawn_attempts": 0,
            "spawn_failures": 0,
            "vehicle_type_distribution": defaultdict(int)
        }
        
        # Mumbai-specific patterns
        self.mumbai_patterns = {
            "peak_hours": [(7, 10), (17, 20)],  # Morning and evening peaks
            "vehicle_type_ratios": self._calculate_mumbai_ratios(),
            "popular_routes": self._get_popular_routes_pattern()
        }
        
        print(f"Vehicle System initialized:")
        print(f"  Max vehicles: {self.max_vehicles}")
        print(f"  Flow rate: {self.vehicle_flow_per_hour} vehicles/hour")
        print(f"  Vehicle types: {len(self.vehicle_types)}")
    
    def _calculate_mumbai_ratios(self) -> Dict[str, float]:
        """
        Calculate Mumbai-specific vehicle type ratios
        
        Returns:
            Dict: Vehicle type ratios
        """
        ratios = {}
        total_prob = sum(vtype.get("probability", 0) for vtype in self.vehicle_types.values())
        
        for vtype_name, vtype_config in self.vehicle_types.items():
            # Adjust probabilities for Mumbai
            base_prob = vtype_config.get("probability", 0.1)
            
            # Mumbai-specific adjustments
            mumbai_factors = {
                "motorcycle": 1.3,      # More motorcycles
                "auto_rickshaw": 1.2,   # More auto rickshaws
                "truck": 0.8,           # Fewer trucks in city center
                "bus": 0.9,             # Slightly fewer buses
                "emergency": 1.0,       # Normal
                "passenger": 1.0        # Normal
            }
            
            factor = mumbai_factors.get(vtype_name, 1.0)
            adjusted_prob = base_prob * factor
            ratios[vtype_name] = adjusted_prob / total_prob if total_prob > 0 else 0
        
        # Normalize
        total = sum(ratios.values())
        if total > 0:
            ratios = {k: v/total for k, v in ratios.items()}
        
        return ratios
    
    def _get_popular_routes_pattern(self) -> List[Tuple[str, str]]:
        """
        Get popular route patterns for Mumbai
        
        Returns:
            List: (from_edge, to_edge) patterns
        """
        # These would be dynamically loaded from network analysis
        # For now, return placeholder patterns
        return [
            ("edge1", "edge10"),    # North-South corridor
            ("edge5", "edge15"),    # East-West corridor
            ("edge20", "edge30"),   # Ring road
            ("edge8", "edge25")     # CBD access
        ]
    
    def _calculate_spawn_interval(self) -> float:
        """
        Calculate next spawn interval based on flow rate
        
        Returns:
            float: Spawn interval in seconds
        """
        # Base on flow rate
        base_interval = 3600.0 / self.vehicle_flow_per_hour
        
        # Add randomness
        interval = random.normalvariate(
            base_interval * self.spawn_interval_mean,
            base_interval * self.spawn_interval_std
        )
        
        # Ensure positive
        return max(0.1, interval)
    
    def update(self, traci_conn, step: int):
        """
        Update vehicle system - spawn and manage vehicles
        
        Args:
            traci_conn: TraCI connection
            step: Current simulation step
        """
        step_length = self.config["simulation"]["step_length"]
        current_time = step * step_length
        
        # 1. Check if it's time to spawn new vehicles
        if self._should_spawn_vehicle(current_time):
            self._spawn_vehicles(traci_conn, current_time)
        
        # 2. Update active vehicles tracking
        self._update_active_vehicles(traci_conn)
        
        # 3. Clean up despawned vehicles
        self._cleanup_despawned_vehicles(traci_conn)
        
        # 4. Update statistics
        self._update_statistics()
    
    def _should_spawn_vehicle(self, current_time: float) -> bool:
        """
        Check if we should spawn a vehicle
        
        Args:
            current_time: Current simulation time
            
        Returns:
            bool: True if should spawn
        """
        # Check interval
        if current_time - self.last_spawn_time < self.next_spawn_interval:
            return False
        
        # Check max vehicles
        if len(self.active_vehicles) >= self.max_vehicles:
            return False
        
        # Adjust spawn rate based on time of day (Mumbai pattern)
        hour_of_day = (current_time / 3600) % 24
        in_peak_hour = any(start <= hour_of_day < end 
                          for start, end in self.mumbai_patterns["peak_hours"])
        
        # Increase spawn rate during peak hours
        if in_peak_hour and random.random() < 0.7:  # 70% chance to spawn during peak
            return True
        
        # Normal spawn probability
        spawn_prob = 0.3 if len(self.active_vehicles) < self.max_vehicles * 0.7 else 0.1
        return random.random() < spawn_prob
    
    def _spawn_vehicles(self, traci_conn, current_time: float):
        """
        Spawn new vehicles
        
        Args:
            traci_conn: TraCI connection
            current_time: Current simulation time
        """
        self.stats["spawn_attempts"] += 1
        
        try:
            # Determine how many vehicles to spawn (1-3 based on density)
            active_count = len(self.active_vehicles)
            density_factor = min(1.0, active_count / (self.max_vehicles * 0.8))
            
            if density_factor > 0.7:  # High density
                spawn_count = 1
            elif density_factor > 0.4:  # Medium density
                spawn_count = 2 if random.random() < 0.5 else 1
            else:  # Low density
                spawn_count = 3 if random.random() < 0.3 else 2
            
            # Spawn vehicles
            for _ in range(spawn_count):
                if len(self.active_vehicles) >= self.max_vehicles:
                    break
                
                self._spawn_single_vehicle(traci_conn, current_time)
            
            # Update spawn timing
            self.last_spawn_time = current_time
            self.next_spawn_interval = self._calculate_spawn_interval()
            
        except Exception as e:
            self.stats["spawn_failures"] += 1
            print(f"⚠ Vehicle spawn error: {e}")
    
    def _spawn_single_vehicle(self, traci_conn, current_time: float):
        """
        Spawn a single vehicle
        
        Args:
            traci_conn: TraCI connection
            current_time: Current simulation time
        """
        # 1. Select vehicle type based on Mumbai ratios
        vehicle_type = self._select_vehicle_type()
        
        # 2. Generate unique vehicle ID
        vehicle_id = self._generate_vehicle_id(vehicle_type)
        
        # 3. Select route
        route_id, from_edge, to_edge = self._select_route(traci_conn)
        if not route_id:
            return
        
        # 4. Set vehicle parameters
        vtype_config = self.vehicle_types.get(vehicle_type, {})
        
        # 5. Spawn vehicle
        try:
            traci_conn.vehicle.add(
                vehID=vehicle_id,
                routeID=route_id,
                typeID=vehicle_type,
                depart="now",
                departLane=self.depart_lane,
                departPos=self.depart_pos,
                departSpeed=self.depart_speed
            )
            
            # Apply vehicle-specific parameters
            self._apply_vehicle_parameters(vehicle_id, vtype_config, traci_conn)
            
            # Track vehicle
            self.spawned_vehicles.add(vehicle_id)
            self.active_vehicles.add(vehicle_id)
            self.vehicle_type_counts[vehicle_type] += 1
            self.vehicle_routes[vehicle_id] = route_id
            
            self.stats["total_spawned"] += 1
            self.stats["vehicle_type_distribution"][vehicle_type] += 1
            
        except Exception as e:
            # Vehicle spawn failed
            print(f"⚠ Failed to spawn vehicle {vehicle_id}: {e}")
            self.stats["spawn_failures"] += 1
    
    def _select_vehicle_type(self) -> str:
        """
        Select vehicle type based on Mumbai ratios
        
        Returns:
            str: Selected vehicle type
        """
        ratios = self.mumbai_patterns["vehicle_type_ratios"]
        
        # Convert to cumulative probabilities
        cumulative = 0
        items = []
        for vtype, prob in ratios.items():
            cumulative += prob
            items.append((vtype, cumulative))
        
        # Select random
        r = random.random()
        for vtype, cum_prob in items:
            if r <= cum_prob:
                return vtype
        
        # Fallback
        return "passenger"
    
    def _generate_vehicle_id(self, vehicle_type: str) -> str:
        """
        Generate unique vehicle ID
        
        Args:
            vehicle_type: Vehicle type
            
        Returns:
            str: Unique vehicle ID
        """
        timestamp = int(time.time() * 1000) % 1000000
        random_suffix = random.randint(1000, 9999)
        
        # Short type codes
        type_codes = {
            "motorcycle": "MC",
            "auto_rickshaw": "AR",
            "passenger": "PV",
            "truck": "TK",
            "bus": "BS",
            "emergency": "EM"
        }
        
        type_code = type_codes.get(vehicle_type, "VH")
        return f"{type_code}_{timestamp}_{random_suffix}"
    
    def _select_route(self, traci_conn) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """
        Select route for vehicle
        
        Args:
            traci_conn: TraCI connection
            
        Returns:
            tuple: (route_id, from_edge, to_edge) or (None, None, None)
        """
        try:
            # Get all available routes
            route_ids = traci_conn.route.getIDList()
            
            # If no routes exist, try to create one dynamically
            if not route_ids:
                return self._create_dynamic_route(traci_conn)
            
            # Weight routes by popularity (simplified)
            popular_routes = self.mumbai_patterns["popular_routes"]
            
            if popular_routes and random.random() < 0.6:  # 60% chance for popular route
                # Try to find a matching route
                for from_edge, to_edge in popular_routes:
                    for route_id in route_ids:
                        edges = traci_conn.route.getEdges(route_id)
                        if edges and edges[0] == from_edge and edges[-1] == to_edge:
                            return route_id, from_edge, to_edge
            
            # Fallback: random route
            route_id = random.choice(route_ids)
            edges = traci_conn.route.getEdges(route_id)
            from_edge = edges[0] if edges else None
            to_edge = edges[-1] if edges else None
            
            return route_id, from_edge, to_edge
            
        except Exception:
            return None, None, None

    def _create_dynamic_route(self, traci_conn) -> Tuple[Optional[str], Optional[str], Optional[str]]:
        """
        Create a random route dynamically
        """
        try:
            edge_ids = [e for e in traci_conn.edge.getIDList() if ":" not in e]
            if len(edge_ids) < 2:
                return None, None, None
                
            # Try 10 times to find a valid route
            for _ in range(10):
                from_edge = random.choice(edge_ids)
                to_edge = random.choice(edge_ids)
                
                if from_edge == to_edge:
                    continue
                    
                stage = traci_conn.simulation.findRoute(from_edge, to_edge)
                if stage and stage.edges:
                    route_id = f"dynamic_{from_edge}_{to_edge}_{int(time.time()*1000)}"
                    traci_conn.route.add(route_id, stage.edges)
                    return route_id, from_edge, to_edge
            
            return None, None, None
        except Exception as e:
            print(f"Failed to create dynamic route: {e}")
            return None, None, None
    
    def _apply_vehicle_parameters(self, vehicle_id: str, vtype_config: Dict, traci_conn):
        """
        Apply vehicle-specific parameters
        
        Args:
            vehicle_id: Vehicle ID
            vtype_config: Vehicle type configuration
            traci_conn: TraCI connection
        """
        try:
            # Set color based on vehicle type
            colors = {
                "motorcycle": (255, 100, 100, 255),      # Red
                "auto_rickshaw": (100, 255, 100, 255),   # Green
                "passenger": (100, 100, 255, 255),       # Blue
                "truck": (255, 200, 100, 255),           # Orange
                "bus": (200, 100, 255, 255),             # Purple
                "emergency": (255, 255, 100, 255)        # Yellow
            }
            
            color = colors.get(vtype_config.get("shape", "passenger"), (255, 255, 255, 255))
            traci_conn.vehicle.setColor(vehicle_id, color)
            
            # Set additional parameters
            traci_conn.vehicle.setParameter(vehicle_id, "device.battery.actualBatteryCapacity", "100")
            traci_conn.vehicle.setParameter(vehicle_id, "has.rerouting.device", "true")
            
            # Set Mumbai-specific driving behavior
            self._apply_mumbai_driving_behavior(vehicle_id, vtype_config, traci_conn)
            
        except Exception:
            pass  # Silently fail
    
    def _apply_mumbai_driving_behavior(self, vehicle_id: str, vtype_config: Dict, traci_conn):
        """
        Apply Mumbai-specific driving behavior
        
        Args:
            vehicle_id: Vehicle ID
            vtype_config: Vehicle type configuration
            traci_conn: TraCI connection
        """
        try:
            vtype = vtype_config.get("shape", "passenger")
            
            # Mumbai driving characteristics
            mumbai_behaviors = {
                "motorcycle": {
                    "lcAssertive": "1.8",      # More assertive lane changes
                    "lcPushy": "0.3",          # Slightly pushy
                    "speedFactor": "1.1",      # Slightly faster
                    "minGap": "0.3"            # Smaller gaps
                },
                "auto_rickshaw": {
                    "lcAssertive": "1.5",
                    "lcPushy": "0.2",
                    "speedFactor": "1.0",
                    "minGap": "0.5"
                },
                "passenger": {
                    "lcAssertive": "1.2",
                    "lcPushy": "0.1",
                    "speedFactor": "1.0",
                    "minGap": "1.0"
                },
                "truck": {
                    "lcAssertive": "0.8",      # Less assertive
                    "lcPushy": "0.0",
                    "speedFactor": "0.9",      # Slower
                    "minGap": "2.0"            # Larger gaps
                },
                "bus": {
                    "lcAssertive": "0.7",
                    "lcPushy": "0.0",
                    "speedFactor": "0.9",
                    "minGap": "2.5"
                },
                "emergency": {
                    "lcAssertive": "2.0",      # Very assertive
                    "lcPushy": "0.5",
                    "speedFactor": "1.3",      # Faster
                    "minGap": "0.8"
                }
            }
            
            behavior = mumbai_behaviors.get(vtype, {})
            
            for param, value in behavior.items():
                if param == "lcAssertive":
                    traci_conn.vehicle.setParameter(vehicle_id, "laneChangeModel.lcAssertive", value)
                elif param == "lcPushy":
                    traci_conn.vehicle.setParameter(vehicle_id, "laneChangeModel.lcPushy", value)
                elif param == "speedFactor":
                    traci_conn.vehicle.setSpeedFactor(vehicle_id, float(value))
                elif param == "minGap":
                    traci_conn.vehicle.setMinGap(vehicle_id, float(value))
            
            # Add Mumbai-specific parameter
            traci_conn.vehicle.setParameter(vehicle_id, "mumbai.driving.style", "aggressive")
            
        except Exception:
            pass
    
    def _update_active_vehicles(self, traci_conn):
        """
        Update tracking of active vehicles
        
        Args:
            traci_conn: TraCI connection
        """
        current_vehicles = set(traci_conn.vehicle.getIDList())
        self.active_vehicles = self.active_vehicles.intersection(current_vehicles)
        
        # Add any vehicles we didn't track (spawned by other means)
        for veh_id in current_vehicles:
            if veh_id not in self.active_vehicles:
                self.active_vehicles.add(veh_id)
    
    def _cleanup_despawned_vehicles(self, traci_conn):
        """
        Clean up tracking for despawned vehicles
        
        Args:
            traci_conn: TraCI connection
        """
        current_vehicles = set(traci_conn.vehicle.getIDList())
        despawned = self.spawned_vehicles - current_vehicles
        
        for veh_id in despawned:
            self.spawned_vehicles.discard(veh_id)
            self.vehicle_routes.pop(veh_id, None)
            
            # Update type counts (we need to track type per vehicle)
            # This would require storing vehicle type per ID
        
        if despawned:
            self.stats["total_despawned"] += len(despawned)
    
    def _update_statistics(self):
        """
        Update system statistics
        """
        self.stats["current_count"] = len(self.active_vehicles)
        self.stats["max_concurrent"] = max(
            self.stats["max_concurrent"], 
            len(self.active_vehicles)
        )
    
    def get_active_vehicle_count(self) -> int:
        """
        Get count of active vehicles
        
        Returns:
            int: Active vehicle count
        """
        return len(self.active_vehicles)
    
    def get_spawned_count(self) -> int:
        """
        Get count of spawned vehicles in this step
        
        Returns:
            int: Spawned vehicle count
        """
        # Simplified implementation
        spawned_this_step = 0
        if hasattr(self, '_last_spawned_count'):
            spawned_this_step = self._last_spawned_count
            self._last_spawned_count = 0
        return spawned_this_step
    
    def get_despawned_count(self) -> int:
        """
        Get count of despawned vehicles in this step
        
        Returns:
            int: Despawned vehicle count
        """
        # Simplified implementation
        return 0
    
    def get_statistics(self) -> Dict:
        """
        Get vehicle system statistics
        
        Returns:
            Dict: Statistics
        """
        stats = self.stats.copy()
        stats["active_vehicles"] = len(self.active_vehicles)
        stats["spawned_vehicles"] = len(self.spawned_vehicles)
        stats["vehicle_type_counts"] = dict(self.vehicle_type_counts)
        
        # Calculate spawn success rate
        if stats["spawn_attempts"] > 0:
            stats["spawn_success_rate"] = (
                (stats["spawn_attempts"] - stats["spawn_failures"]) / 
                stats["spawn_attempts"]
            ) * 100
        else:
            stats["spawn_success_rate"] = 0
        
        return stats
    
    def get_vehicle_type_distribution(self) -> Dict[str, float]:
        """
        Get current vehicle type distribution
        
        Returns:
            Dict: Type -> percentage
        """
        total = sum(self.vehicle_type_counts.values())
        if total == 0:
            return {}
        
        return {
            vtype: count / total * 100
            for vtype, count in self.vehicle_type_counts.items()
        }
    
    def reset(self):
        """Reset vehicle system"""
        self.spawned_vehicles.clear()
        self.active_vehicles.clear()
        self.vehicle_type_counts.clear()
        self.vehicle_routes.clear()
        
        self.last_spawn_time = 0
        self.next_spawn_interval = self._calculate_spawn_interval()
        
        self.stats = {
            "total_spawned": 0,
            "total_despawned": 0,
            "current_count": 0,
            "max_concurrent": 0,
            "spawn_attempts": 0,
            "spawn_failures": 0,
            "vehicle_type_distribution": defaultdict(int)
        }


# Test function
def test_vehicle_system():
    """Test vehicle system functionality"""
    print("Testing Vehicle System...")
    
    # Create test config
    test_config = {
        "simulation": {
            "step_length": 0.1,
            "max_vehicles": 1000
        },
        "vehicle_generation": {
            "vehicle_flow_per_hour": 1000,
            "spawn_interval_mean": 1.0,
            "spawn_interval_std": 0.2,
            "depart_pos": "random",
            "depart_speed": "random",
            "depart_lane": "best"
        },
        "vehicle_types": {
            "motorcycle": {"probability": 0.4, "shape": "motorcycle"},
            "auto_rickshaw": {"probability": 0.3, "shape": "delivery"},
            "passenger": {"probability": 0.3, "shape": "passenger"}
        }
    }
    
    # Create vehicle system
    vehicle_system = VehicleSystem(test_config)
    
    print(f"✓ Vehicle system initialized")
    print(f"  Max vehicles: {vehicle_system.max_vehicles}")
    print(f"  Flow rate: {vehicle_system.vehicle_flow_per_hour}")
    
    # Test Mumbai ratios
    ratios = vehicle_system.mumbai_patterns["vehicle_type_ratios"]
    print(f"  Mumbai ratios: {ratios}")
    
    # Test statistics
    stats = vehicle_system.get_statistics()
    print(f"  Initial stats: {stats}")
    
    print("Test completed!")


if __name__ == "__main__":
    test_vehicle_system()