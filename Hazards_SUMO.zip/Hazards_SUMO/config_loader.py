"""
CONFIG LOADER - Mumbai Traffic Simulation
Loads and validates configuration from JSON file
Ensures all required fields are present and valid
"""

import json
import os
import sys
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class ConfigValidationResult:
    """Result of configuration validation"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]

class ConfigLoader:
    """
    Handles loading, validating, and providing default values for configuration
    """
    
    # Default configuration template
    DEFAULT_CONFIG = {
        "simulation": {
            "mode": "test",
            "city": "Mumbai",
            "seed": 42,
            "step_length": 0.1,
            "duration_seconds": 1800,
            "warmup_seconds": 300,
            "max_vehicles": 12000,
            "sumo_binary": "sumo",
            "net_file": "osm_networks/mumbai.net.xml",
            "route_file": "osm_networks/mumbai.rou.xml",
            "additional_file": "osm_networks/mumbai.add.xml",
            "gui": False,
            "port": 8813,
            "csv_append_mode": True,
            "real_time_monitoring": False,
            "min_vehicles_for_accident": 15
        },
        "network": {
            "left_hand_traffic": True,
            "traffic_lights": True,
            "default_speed": 50.0
        },
        "vehicle_generation": {
            "vehicle_flow_per_hour": 3000,
            "depart_pos": "random",
            "depart_speed": "random",
            "depart_lane": "best",
            "spawn_interval_mean": 1.0,
            "spawn_interval_std": 0.2
        },
        "vehicle_types": {
            "motorcycle": {
                "probability": 0.40,
                "length": 2.0,
                "width": 0.8,
                "max_speed": 80.0,
                "acceleration": 2.5,
                "deceleration": 4.5,
                "min_gap": 0.5,
                "shape": "motorcycle"
            },
            "auto_rickshaw": {
                "probability": 0.25,
                "length": 2.5,
                "width": 1.4,
                "max_speed": 60.0,
                "acceleration": 1.8,
                "deceleration": 4.0,
                "min_gap": 1.0,
                "shape": "delivery"
            },
            "passenger": {
                "probability": 0.20,
                "length": 4.5,
                "width": 1.8,
                "max_speed": 100.0,
                "acceleration": 2.0,
                "deceleration": 4.5,
                "min_gap": 2.0,
                "shape": "passenger"
            },
            "truck": {
                "probability": 0.08,
                "length": 10.0,
                "width": 2.5,
                "max_speed": 70.0,
                "acceleration": 1.2,
                "deceleration": 3.0,
                "min_gap": 3.0,
                "shape": "truck"
            },
            "bus": {
                "probability": 0.05,
                "length": 12.0,
                "width": 2.5,
                "max_speed": 65.0,
                "acceleration": 1.0,
                "deceleration": 3.0,
                "min_gap": 3.5,
                "shape": "bus"
            },
            "emergency": {
                "probability": 0.02,
                "length": 5.0,
                "width": 2.0,
                "max_speed": 120.0,
                "acceleration": 3.0,
                "deceleration": 6.0,
                "min_gap": 1.5,
                "emergency_vehicle": True,
                "shape": "emergency"
            }
        },
        "hazards": {
            "hazard_priority": {
                "ACCIDENT": 1,
                "EMERGENCY_VEHICLE": 2,
                "CONGESTION": 3,
                "WRONG_WAY": 4,
                "IGNORE_RED_LIGHT": 5,
                "SUDDEN_BRAKING": 6,
                "AGGRESSIVE_LANE_CHANGE": 7,
                "TAILGATING": 8,
                "SPEEDING": 9,
                "SLIPPERY_ROAD": 10
            },
            "hazard_check_interval_seconds": 5,
            "test_mode_probabilities": {
                "ACCIDENT": 0.03,
                "EMERGENCY_VEHICLE": 0.05,
                "CONGESTION": 0.08,
                "WRONG_WAY": 0.02,
                "IGNORE_RED_LIGHT": 0.05,
                "SUDDEN_BRAKING": 0.08,
                "AGGRESSIVE_LANE_CHANGE": 0.07,
                "TAILGATING": 0.06,
                "SPEEDING": 0.08,
                "SLIPPERY_ROAD": 0.04
            },
            "production_mode_probabilities": {
                "ACCIDENT": 0.002,
                "EMERGENCY_VEHICLE": 0.005,
                "CONGESTION": 0.01,
                "WRONG_WAY": 0.001,
                "IGNORE_RED_LIGHT": 0.004,
                "SUDDEN_BRAKING": 0.008,
                "AGGRESSIVE_LANE_CHANGE": 0.006,
                "TAILGATING": 0.005,
                "SPEEDING": 0.01,
                "SLIPPERY_ROAD": 0.003
            },
            "max_congested_edges": 3,
            "congestion_min_duration": 120,
            "congestion_max_duration": 600,
            "tailgating_min_duration": 30,
            "tailgating_max_duration": 90,
            "max_tailgaters": 3
        },
        "output": {
            "csv_schema": [
                "run_id",
                "timestamp",
                "vehicle_id",
                "x_pos",
                "y_pos",
                "rsu_id",
                "edge_id",
                "lane_id",
                "speed",
                "acceleration",
                "lane_position",
                "gap_to_leader",
                "signal_state",
                "hazard_type"
            ],
            "csv_filename": "traffic_events.csv",
            "window_csv_filename": "traffic_ml_windows.csv",
            "sliding_window": {
                "window_size_seconds": 10,
                "step_seconds": 1
            },
            "write_only_on_event": True
        }
    }
    
    # Required fields that must be present in config
    REQUIRED_FIELDS = {
        "simulation": ["mode", "step_length", "duration_seconds", "net_file", "route_file"],
        "network": ["left_hand_traffic"],
        "vehicle_generation": ["vehicle_flow_per_hour"],
        "vehicle_types": ["motorcycle", "auto_rickshaw", "passenger"],
        "hazards": ["hazard_priority", "hazard_check_interval_seconds", "test_mode_probabilities"],
        "output": ["csv_schema", "csv_filename"]
    }
    
    def __init__(self):
        """Initialize config loader"""
        self.config = {}
        self.validation_result = ConfigValidationResult(True, [], [])
    
    def load_config(self, config_path: str = "config.json") -> Dict[str, Any]:
        """
        Load configuration from JSON file with validation
        
        Args:
            config_path: Path to configuration JSON file
            
        Returns:
            Dict: Loaded and validated configuration
            
        Raises:
            FileNotFoundError: If config file doesn't exist
            json.JSONDecodeError: If config is not valid JSON
            ValueError: If config validation fails
        """
        print(f"Loading configuration from: {config_path}")
        
        # Check if file exists
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        # Load JSON
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        except json.JSONDecodeError as e:
            raise json.JSONDecodeError(f"Invalid JSON in config file: {e}", e.doc, e.pos)
        
        # Validate configuration
        self.validation_result = self._validate_config(self.config)
        
        if not self.validation_result.is_valid:
            error_msg = "Configuration validation failed:\n" + "\n".join(self.validation_result.errors)
            raise ValueError(error_msg)
        
        # Apply defaults for missing optional fields
        self.config = self._apply_defaults(self.config)
        
        # Additional consistency checks
        self._perform_consistency_checks()
        
        print(f"✓ Configuration loaded successfully")
        print(f"  Mode: {self.config['simulation']['mode']}")
        print(f"  Duration: {self.config['simulation']['duration_seconds']} seconds")
        print(f"  Hazards: {len(self.config['hazards']['hazard_priority'])} types")
        
        if self.validation_result.warnings:
            print(f"⚠ Configuration warnings:")
            for warning in self.validation_result.warnings:
                print(f"  • {warning}")
        
        return self.config
    
    def _validate_config(self, config: Dict) -> ConfigValidationResult:
        """
        Validate configuration structure and values
        
        Args:
            config: Configuration dictionary to validate
            
        Returns:
            ConfigValidationResult: Validation result
        """
        errors = []
        warnings = []
        
        # Check required sections
        for section, required_fields in self.REQUIRED_FIELDS.items():
            if section not in config:
                errors.append(f"Missing required section: '{section}'")
                continue
            
            # Check required fields in section
            for field in required_fields:
                if field not in config[section]:
                    errors.append(f"Missing required field: '{section}.{field}'")
        
        # Validate simulation parameters
        if "simulation" in config:
            sim = config["simulation"]
            
            # Step length must be positive
            if sim.get("step_length", 0) <= 0:
                errors.append("simulation.step_length must be > 0")
            
            # Duration must be positive
            if sim.get("duration_seconds", 0) <= 0:
                errors.append("simulation.duration_seconds must be > 0")
            
            # Max vehicles must be positive
            if sim.get("max_vehicles", 0) <= 0:
                errors.append("simulation.max_vehicles must be > 0")
        
        # Validate vehicle type probabilities sum to <= 1
        if "vehicle_types" in config:
            total_prob = 0
            for vtype, params in config["vehicle_types"].items():
                prob = params.get("probability", 0)
                total_prob += prob
                
                # Check individual parameters
                if prob < 0 or prob > 1:
                    warnings.append(f"vehicle_types.{vtype}.probability should be between 0 and 1")
                
                if params.get("max_speed", 0) <= 0:
                    warnings.append(f"vehicle_types.{vtype}.max_speed should be > 0")
            
            if total_prob > 1.0:
                warnings.append(f"Sum of vehicle type probabilities ({total_prob:.2f}) exceeds 1.0")
        
        # Validate hazard probabilities
        if "hazards" in config:
            hazards = config["hazards"]
            
            # Check test mode probabilities
            if "test_mode_probabilities" in hazards:
                for hazard, prob in hazards["test_mode_probabilities"].items():
                    if prob < 0 or prob > 1:
                        warnings.append(f"hazards.test_mode_probabilities.{hazard} should be between 0 and 1")
            
            # Check production mode probabilities
            if "production_mode_probabilities" in hazards:
                for hazard, prob in hazards["production_mode_probabilities"].items():
                    if prob < 0 or prob > 1:
                        warnings.append(f"hazards.production_mode_probabilities.{hazard} should be between 0 and 1")
        
        # Validate output configuration
        if "output" in config:
            output = config["output"]
            
            # Check sliding window configuration
            if "sliding_window" in output:
                window = output["sliding_window"]
                if window.get("window_size_seconds", 0) <= 0:
                    errors.append("output.sliding_window.window_size_seconds must be > 0")
                if window.get("step_seconds", 0) <= 0:
                    errors.append("output.sliding_window.step_seconds must be > 0")
                if window.get("step_seconds", 0) > window.get("window_size_seconds", 1):
                    warnings.append("output.sliding_window.step_seconds should be <= window_size_seconds")
        
        # Check if hazard names in probabilities match priority list
        if "hazards" in config:
            hazards = config["hazards"]
            priority_names = set(hazards.get("hazard_priority", {}).keys())
            
            # Check test mode
            test_prob_names = set(hazards.get("test_mode_probabilities", {}).keys())
            if priority_names != test_prob_names:
                warnings.append("Hazard names in hazard_priority and test_mode_probabilities don't match")
            
            # Check production mode
            prod_prob_names = set(hazards.get("production_mode_probabilities", {}).keys())
            if priority_names != prod_prob_names:
                warnings.append("Hazard names in hazard_priority and production_mode_probabilities don't match")
        
        is_valid = len(errors) == 0
        return ConfigValidationResult(is_valid, errors, warnings)
    
    def _apply_defaults(self, config: Dict) -> Dict:
        """
        Apply default values for missing optional fields
        
        Args:
            config: Configuration dictionary
            
        Returns:
            Dict: Configuration with defaults applied
        """
        def merge_dicts(base: Dict, override: Dict) -> Dict:
            """Recursively merge dictionaries"""
            result = base.copy()
            for key, value in override.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] = merge_dicts(result[key], value)
                else:
                    result[key] = value
            return result
        
        # Start with defaults and override with user config
        return merge_dicts(self.DEFAULT_CONFIG, config)
    
    def _perform_consistency_checks(self):
        """Perform additional consistency checks on the configuration"""
        warnings = []
        
        # Check file paths exist
        sim = self.config.get("simulation", {})
        required_files = ["net_file", "route_file", "additional_file"]
        
        for file_key in required_files:
            if file_key in sim:
                file_path = sim[file_key]
                if not os.path.exists(file_path):
                    warnings.append(f"File does not exist: {file_path}")
        
        # Check probability mode consistency
        sim_mode = sim.get("mode", "test")
        hazards = self.config.get("hazards", {})
        
        if sim_mode == "test" and "test_mode_probabilities" not in hazards:
            warnings.append("Test mode selected but test_mode_probabilities not configured")
        elif sim_mode == "production" and "production_mode_probabilities" not in hazards:
            warnings.append("Production mode selected but production_mode_probabilities not configured")
        
        # Add warnings to validation result
        self.validation_result.warnings.extend(warnings)
    
    def get_validation_result(self) -> ConfigValidationResult:
        """
        Get the result of the last validation
        
        Returns:
            ConfigValidationResult: Validation result
        """
        return self.validation_result
    
    def get_hazard_config(self, hazard_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific hazard
        
        Args:
            hazard_name: Name of the hazard
            
        Returns:
            Dict: Hazard configuration
        """
        hazards = self.config.get("hazards", {})
        
        # Get probability based on simulation mode
        sim_mode = self.config.get("simulation", {}).get("mode", "test")
        if sim_mode == "test":
            prob_key = "test_mode_probabilities"
        else:
            prob_key = "production_mode_probabilities"
        
        probability = hazards.get(prob_key, {}).get(hazard_name, 0)
        priority = hazards.get("hazard_priority", {}).get(hazard_name, 99)
        
        return {
            "probability": probability,
            "priority": priority,
            "check_interval": hazards.get("hazard_check_interval_seconds", 5),
            "name": hazard_name
        }
    
    def get_vehicle_type_config(self, vehicle_type: str) -> Dict[str, Any]:
        """
        Get configuration for a specific vehicle type
        
        Args:
            vehicle_type: Type of vehicle
            
        Returns:
            Dict: Vehicle type configuration
        """
        vehicle_types = self.config.get("vehicle_types", {})
        return vehicle_types.get(vehicle_type, {})
    
    def save_config(self, config: Dict, output_path: str):
        """
        Save configuration to JSON file
        
        Args:
            config: Configuration dictionary
            output_path: Path to save configuration
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            print(f"✓ Configuration saved to: {output_path}")
        except Exception as e:
            print(f"❌ Failed to save configuration: {e}")
            raise
    
    def create_minimal_config(self, output_path: str = "config_minimal.json"):
        """
        Create a minimal configuration template
        
        Args:
            output_path: Path to save minimal config
        """
        minimal_config = {
            "simulation": {
                "mode": "test",
                "city": "Mumbai",
                "step_length": 0.1,
                "duration_seconds": 600,
                "net_file": "osm_networks/mumbai.net.xml",
                "route_file": "osm_networks/mumbai.rou.xml",
                "additional_file": "osm_networks/mumbai.add.xml"
            },
            "network": {
                "left_hand_traffic": True
            },
            "vehicle_generation": {
                "vehicle_flow_per_hour": 1000
            },
            "vehicle_types": {
                "motorcycle": {
                    "probability": 0.4,
                    "max_speed": 80.0
                },
                "auto_rickshaw": {
                    "probability": 0.3,
                    "max_speed": 60.0
                }
            },
            "hazards": {
                "hazard_priority": {
                    "ACCIDENT": 1,
                    "CONGESTION": 2
                },
                "hazard_check_interval_seconds": 5,
                "test_mode_probabilities": {
                    "ACCIDENT": 0.01,
                    "CONGESTION": 0.05
                }
            },
            "output": {
                "csv_schema": ["timestamp", "vehicle_id", "speed", "hazard_type"],
                "csv_filename": "traffic_events.csv"
            }
        }
        
        self.save_config(minimal_config, output_path)


# Convenience function for easy importing
def load_config(config_path: str = "config.json") -> Dict[str, Any]:
    """
    Load and validate configuration from file
    
    Args:
        config_path: Path to configuration file
        
    Returns:
        Dict: Validated configuration
        
    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If config validation fails
    """
    loader = ConfigLoader()
    return loader.load_config(config_path)


def validate_config(config: Dict) -> ConfigValidationResult:
    """
    Validate a configuration dictionary
    
    Args:
        config: Configuration dictionary to validate
        
    Returns:
        ConfigValidationResult: Validation result
    """
    loader = ConfigLoader()
    return loader._validate_config(config)


def create_config_template(output_path: str = "config_template.json"):
    """
    Create a complete configuration template
    
    Args:
        output_path: Path to save template
    """
    loader = ConfigLoader()
    loader.save_config(loader.DEFAULT_CONFIG, output_path)


# Example usage and testing
if __name__ == "__main__":
    print("Config Loader Test")
    print("=" * 60)
    
    # Test loading
    try:
        # Create a test config if it doesn't exist
        if not os.path.exists("test_config.json"):
            loader = ConfigLoader()
            loader.save_config(loader.DEFAULT_CONFIG, "test_config.json")
        
        # Load config
        config = load_config("test_config.json")
        
        print("✓ Configuration loaded successfully")
        print(f"  Simulation mode: {config['simulation']['mode']}")
        print(f"  Step length: {config['simulation']['step_length']}")
        print(f"  Hazard types: {len(config['hazards']['hazard_priority'])}")
        
        # Test hazard config retrieval
        hazard_config = ConfigLoader().get_hazard_config("ACCIDENT")
        print(f"  ACCIDENT probability: {hazard_config['probability']}")
        
        # Test vehicle type config
        vehicle_config = ConfigLoader().get_vehicle_type_config("motorcycle")
        print(f"  Motorcycle max speed: {vehicle_config['max_speed']}")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
    
    print("\nCreating minimal config template...")
    try:
        loader = ConfigLoader()
        loader.create_minimal_config("config_minimal.json")
        print("✓ Minimal config created: config_minimal.json")
    except Exception as e:
        print(f"❌ Failed to create minimal config: {e}")
    
    print("\nCreating full config template...")
    try:
        create_config_template("config_template.json")
        print("✓ Full config template created: config_template.json")
    except Exception as e:
        print(f"❌ Failed to create template: {e}")