"""
NETWORK MANAGER - Mumbai Traffic Simulation
Manages network-related operations and traffic light control
"""

import traci
from typing import Dict, List, Optional, Set, Tuple
import random


class NetworkManager:
    """
    Manages network operations including traffic lights and network analysis
    """
    
    def __init__(self, config: Dict):
        """
        Initialize network manager
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.network_config = config.get("network", {})
        
        # Network parameters
        self.left_hand_traffic = self.network_config.get("left_hand_traffic", True)
        self.traffic_lights_enabled = self.network_config.get("traffic_lights", True)
        self.default_speed = self.network_config.get("default_speed", 50.0) / 3.6  # Convert to m/s
        
        # Traffic light management
        self.traffic_lights = []
        self.tls_programs = {}  # tls_id -> program_id
        self.adaptive_tls = {}  # Adaptive traffic light states
        
        # Network analysis
        self.edge_statistics = {}
        self.lane_statistics = {}
        self.congested_edges = set()
        
        # Mumbai-specific network adjustments
        self.mumbai_adjustments = {
            "junction_clearance_time": 3.0,  # Seconds
            "right_turn_on_red": not self.left_hand_traffic,  # Right turn on red if right-hand traffic
            "pedestrian_crossing_time": 15.0,
            "peak_hour_cycle_multiplier": 1.2
        }
        
        # Statistics
        self.stats = {
            "edges_monitored": 0,
            "traffic_lights_controlled": 0,
            "congestion_events": 0,
            "network_updates": 0
        }
        
        print(f"Network Manager initialized:")
        print(f"  Left-hand traffic: {self.left_hand_traffic}")
        print(f"  Traffic lights: {self.traffic_lights_enabled}")
        print(f"  Default speed: {self.default_speed * 3.6:.1f} km/h")
    
    def initialize(self, traci_conn):
        """
        Initialize network with TraCI connection
        
        Args:
            traci_conn: TraCI connection
        """
        print("Initializing network...")
        
        # Get network elements
        self.traffic_lights = traci_conn.trafficlight.getIDList()
        edges = traci_conn.edge.getIDList()
        
        # Filter out internal edges
        self.edges = [e for e in edges if ":" not in e]
        
        # Initialize statistics
        for edge_id in self.edges[:100]:  # Sample edges
            self.edge_statistics[edge_id] = {
                "vehicle_count": 0,
                "avg_speed": self.default_speed,
                "congestion_level": 0,
                "last_update": 0
            }
        
        # Configure traffic lights if enabled
        if self.traffic_lights_enabled:
            self._initialize_traffic_lights(traci_conn)
        
        print(f"✓ Network initialized:")
        print(f"  Edges: {len(self.edges)}")
        print(f"  Traffic lights: {len(self.traffic_lights)}")
        print(f"  Edge statistics: {len(self.edge_statistics)}")
    
    def _initialize_traffic_lights(self, traci_conn):
        """
        Initialize traffic light systems
        
        Args:
            traci_conn: TraCI connection
        """
        for tls_id in self.traffic_lights[:50]:  # Sample traffic lights
            try:
                # Store current program
                programs = traci_conn.trafficlight.getAllProgramLogics(tls_id)
                if programs:
                    self.tls_programs[tls_id] = programs[0].programID
                
                # Configure for Mumbai
                self._configure_mumbai_traffic_light(tls_id, traci_conn)
                
            except Exception as e:
                print(f"⚠ Failed to initialize traffic light {tls_id}: {e}")
        
        self.stats["traffic_lights_controlled"] = len(self.tls_programs)
    
    def _configure_mumbai_traffic_light(self, tls_id: str, traci_conn):
        """
        Configure traffic light for Mumbai conditions
        
        Args:
            tls_id: Traffic light ID
            traci_conn: TraCI connection
        """
        try:
            # Get current logic
            logics = traci_conn.trafficlight.getAllProgramLogics(tls_id)
            if not logics:
                return
            
            logic = logics[0]
            
            # Adjust for left-hand traffic if needed
            if self.left_hand_traffic:
                # Would adjust phase timing for left-hand traffic patterns
                pass
            
            # Store adaptive state
            self.adaptive_tls[tls_id] = {
                "current_phase": 0,
                "phase_durations": [p.duration for p in logic.phases],
                "last_change": 0,
                "vehicle_counts": [0] * len(logic.phases),
                "adaptive_mode": True
            }
            
        except Exception:
            pass
    
    def update(self, traci_conn, simulation_state: Dict):
        """
        Update network management
        
        Args:
            traci_conn: TraCI connection
            simulation_state: Current simulation state
        """
        current_time = simulation_state.get("simulation_time", 0)
        step = simulation_state.get("step", 0)
        
        # Update edge statistics
        if step % 10 == 0:  # Update every 10 steps for efficiency
            self._update_edge_statistics(traci_conn, current_time)
        
        # Update traffic lights (adaptive control)
        if self.traffic_lights_enabled and step % 5 == 0:
            self._update_traffic_lights(traci_conn, current_time)
        
        # Update congestion detection
        if step % 20 == 0:
            self._update_congestion_detection(traci_conn)
        
        self.stats["network_updates"] += 1
    
    def _update_edge_statistics(self, traci_conn, current_time: float):
        """
        Update statistics for monitored edges
        
        Args:
            traci_conn: TraCI connection
            current_time: Current simulation time
        """
        edges_to_update = list(self.edge_statistics.keys())[:50]  # Sample edges
        
        for edge_id in edges_to_update:
            try:
                vehicle_count = traci_conn.edge.getLastStepVehicleNumber(edge_id)
                mean_speed = traci_conn.edge.getLastStepMeanSpeed(edge_id)
                
                self.edge_statistics[edge_id].update({
                    "vehicle_count": vehicle_count,
                    "avg_speed": mean_speed if mean_speed > 0 else self.default_speed,
                    "last_update": current_time
                })
                
            except Exception:
                continue
    
    def _update_traffic_lights(self, traci_conn, current_time: float):
        """
        Update adaptive traffic light control
        
        Args:
            traci_conn: TraCI connection
            current_time: Current simulation time
        """
        for tls_id, state in list(self.adaptive_tls.items())[:20]:  # Sample TLS
            try:
                if not state.get("adaptive_mode", True):
                    continue
                
                # Get current phase
                current_phase = traci_conn.trafficlight.getPhase(tls_id)
                state["current_phase"] = current_phase
                
                # Check if phase change is needed based on vehicle counts
                phase_duration = state["phase_durations"][current_phase]
                time_in_phase = current_time - state.get("last_change", 0)
                
                if time_in_phase > phase_duration:
                    # Time to consider phase change
                    waiting_vehicles = self._count_waiting_vehicles(tls_id, current_phase, traci_conn)
                    state["vehicle_counts"][current_phase] = waiting_vehicles
                    
                    # Simple adaptive logic: extend green if many vehicles
                    if waiting_vehicles > 5 and time_in_phase < phase_duration * 2:
                        # Extend green phase
                        traci_conn.trafficlight.setPhaseDuration(tls_id, phase_duration + 5.0)
                    
                    # Consider phase change
                    self._consider_phase_change(tls_id, state, traci_conn, current_time)
                
            except Exception:
                continue
    
    def _count_waiting_vehicles(self, tls_id: str, phase: int, traci_conn) -> int:
        """
        Count vehicles waiting at traffic light
        
        Args:
            tls_id: Traffic light ID
            phase: Current phase
            traci_conn: TraCI connection
            
        Returns:
            int: Number of waiting vehicles
        """
        try:
            # Get lanes controlled by this TLS
            controlled_lanes = traci_conn.trafficlight.getControlledLanes(tls_id)
            
            waiting_count = 0
            for lane_id in controlled_lanes[:10]:  # Sample lanes
                vehicles = traci_conn.lane.getLastStepVehicleIDs(lane_id)
                
                for veh_id in vehicles:
                    speed = traci_conn.vehicle.getSpeed(veh_id)
                    if speed < 0.5:  # Essentially stopped
                        waiting_count += 1
            
            return waiting_count
            
        except Exception:
            return 0
    
    def _consider_phase_change(self, tls_id: str, state: Dict, traci_conn, current_time: float):
        """
        Consider changing traffic light phase
        
        Args:
            tls_id: Traffic light ID
            state: TLS state dictionary
            traci_conn: TraCI connection
            current_time: Current simulation time
        """
        try:
            current_phase = state["current_phase"]
            max_waiting = max(state["vehicle_counts"])
            current_waiting = state["vehicle_counts"][current_phase]
            
            # Change phase if another phase has significantly more waiting vehicles
            if max_waiting > current_waiting * 2 and max_waiting > 3:
                # Find phase with max waiting
                next_phase = state["vehicle_counts"].index(max_waiting)
                
                # Change to that phase
                traci_conn.trafficlight.setPhase(tls_id, next_phase)
                state["last_change"] = current_time
                state["vehicle_counts"] = [0] * len(state["vehicle_counts"])
                
        except Exception:
            pass
    
    def _update_congestion_detection(self, traci_conn):
        """
        Update congestion detection
        
        Args:
            traci_conn: TraCI connection
        """
        congested = set()
        
        for edge_id, stats in list(self.edge_statistics.items())[:100]:
            try:
                vehicle_count = stats["vehicle_count"]
                avg_speed = stats["avg_speed"]
                
                # Congestion criteria
                is_congested = (
                    vehicle_count > 20 or  # High density
                    avg_speed < 5.0 or     # Very slow speed
                    (vehicle_count > 10 and avg_speed < 10.0)  # Moderate density + slow
                )
                
                if is_congested:
                    congested.add(edge_id)
                    
                    # Record congestion event if newly congested
                    if edge_id not in self.congested_edges:
                        self.stats["congestion_events"] += 1
                
            except Exception:
                continue
        
        self.congested_edges = congested
    
    def get_congested_edges(self) -> List[str]:
        """
        Get currently congested edges
        
        Returns:
            List: Congested edge IDs
        """
        return list(self.congested_edges)
    
    def get_edge_statistics(self, edge_id: str) -> Optional[Dict]:
        """
        Get statistics for a specific edge
        
        Args:
            edge_id: Edge ID
            
        Returns:
            Dict: Edge statistics or None
        """
        return self.edge_statistics.get(edge_id)
    
    def get_network_summary(self) -> Dict:
        """
        Get network summary
        
        Returns:
            Dict: Network summary
        """
        total_vehicles = 0
        total_speed = 0
        edge_count = 0
        
        for stats in self.edge_statistics.values():
            total_vehicles += stats["vehicle_count"]
            total_speed += stats["avg_speed"]
            edge_count += 1
        
        avg_vehicles = total_vehicles / edge_count if edge_count > 0 else 0
        avg_speed = total_speed / edge_count if edge_count > 0 else 0
        
        return {
            "total_edges": len(self.edges),
            "monitored_edges": len(self.edge_statistics),
            "traffic_lights": len(self.traffic_lights),
            "congested_edges": len(self.congested_edges),
            "avg_vehicles_per_edge": avg_vehicles,
            "avg_speed_kmh": avg_speed * 3.6,
            "congestion_percentage": (len(self.congested_edges) / len(self.edge_statistics) * 100 
                                     if self.edge_statistics else 0),
            "statistics": self.stats.copy()
        }
    
    def enable_adaptive_traffic_lights(self, enabled: bool = True):
        """
        Enable or disable adaptive traffic light control
        
        Args:
            enabled: True to enable adaptive control
        """
        for tls_id in self.adaptive_tls:
            self.adaptive_tls[tls_id]["adaptive_mode"] = enabled
    
    def set_traffic_light_program(self, tls_id: str, program_id: str, traci_conn):
        """
        Set traffic light program
        
        Args:
            tls_id: Traffic light ID
            program_id: Program ID
            traci_conn: TraCI connection
        """
        try:
            traci_conn.trafficlight.setProgram(tls_id, program_id)
            self.tls_programs[tls_id] = program_id
        except Exception as e:
            print(f"⚠ Failed to set program for {tls_id}: {e}")
    
    def reset(self):
        """Reset network manager"""
        self.edge_statistics.clear()
        self.lane_statistics.clear()
        self.congested_edges.clear()
        self.adaptive_tls.clear()
        
        self.stats = {
            "edges_monitored": 0,
            "traffic_lights_controlled": 0,
            "congestion_events": 0,
            "network_updates": 0
        }


# Test function
def test_network_manager():
    """Test network manager functionality"""
    print("Testing Network Manager...")
    
    # Create test config
    test_config = {
        "network": {
            "left_hand_traffic": True,
            "traffic_lights": True,
            "default_speed": 50.0
        }
    }
    
    # Create network manager
    network_manager = NetworkManager(test_config)
    
    print(f"✓ Network manager initialized")
    print(f"  Left-hand traffic: {network_manager.left_hand_traffic}")
    print(f"  Traffic lights: {network_manager.traffic_lights_enabled}")
    
    # Test summary
    summary = network_manager.get_network_summary()
    print(f"  Initial summary: {summary}")
    
    print("Test completed!")


if __name__ == "__main__":
    test_network_manager()